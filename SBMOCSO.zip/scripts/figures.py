"""Result figures of the paper (Figures 3-9) from the run results.

usage: python scripts/figures.py

Writes output/figures/{dist_err,dist_hv,fronts,panel_size,convergence,rank_budget,budget}.pdf.
"""
from __future__ import annotations

import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import matplotlib.ticker  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib import font_manager  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402
from matplotlib.patches import Patch  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))
import analysis as A  # noqa: E402

FIG = A.OUT / "figures"
ALGS, DATASETS, SHORT = A.ALGS, A.DATASETS, A.SHORT
SCORING_END = 2100   # single-gene evaluations and initial population of the scoring algorithms
STYLE = {
    "NSGA-II": dict(color="#7F7F7F", ls=(0, (5, 1.5, 1, 1.5)), lw=1.0),
    "SparseEA": dict(color="#0072B2", ls="-", lw=1.0),
    "PM-MOEA": dict(color="#1A1A1A", ls="-", lw=1.0),
    "MSKEA": dict(color="#56B4E9", ls=(0, (1, 1.2)), lw=1.2),
    "SparseEA2": dict(color="#009E73", ls="-", lw=1.0),
    "AFSEA": dict(color="#CC79A7", ls="-", lw=1.0),
    "LMOCSO": dict(color="#8C564B", ls=(0, (4, 1.5)), lw=1.0),
    "S-ECSO": dict(color="#5E3C99", ls=(0, (4, 1.5)), lw=1.0),
    "SBMOCSO": dict(color="#D55E00", ls="-", lw=1.8),
}


def set_style():
    names = {f.name for f in font_manager.fontManager.ttflist}
    family = next((f for f in ("Times New Roman", "Liberation Serif", "Nimbus Roman") if f in names), "serif")
    matplotlib.rcParams.update({
        "font.family": family, "mathtext.fontset": "custom", "mathtext.rm": family,
        "mathtext.it": f"{family}:italic", "mathtext.bf": f"{family}:bold", "pdf.fonttype": 42,
        "font.size": 9, "axes.titlesize": 9, "axes.labelsize": 9, "legend.fontsize": 7.5,
        "xtick.labelsize": 8, "ytick.labelsize": 8,
    })


def clean(ax, grid=True):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ax.spines.values():
        s.set_linewidth(0.6)
    ax.tick_params(length=2.5, width=0.6, pad=2)
    if grid:
        ax.grid(axis="y", color="#E6E6E6", lw=0.5)
        ax.set_axisbelow(True)


def compressed_axis(ax, y_lo, y_hi, y_min, share):
    """Linear y axis above y_lo; the range below y_lo is compressed into `share` of the panel height."""
    c = share * (y_hi - y_lo) / ((1 - share) * (y_lo - y_min))
    ax.set_yscale("function", functions=(lambda y: np.where(y >= y_lo, y, y_lo - (y_lo - y) * c),
                                         lambda y: np.where(y >= y_lo, y, y_lo - (y_lo - y) / c)))
    ax.set_ylim(y_min, y_hi)
    ax.yaxis.set_minor_locator(matplotlib.ticker.NullLocator())
    ax.axhline(y_lo, color="#9E9E9E", lw=0.6, ls=(0, (3, 2)), zorder=1)
    ax.plot([0], [y_lo], transform=ax.get_yaxis_transform(), marker=[(-1, -0.6), (1, 0.6)], ms=6,
            ls="none", color="k", mec="k", mew=0.8, clip_on=False, zorder=7)


def fig_boxes(key, ylabel, fname):
    """Figures 3 and 4: distributions over the 30 splits at 10,000 evaluations."""
    R = {a: A.load("main", a) for a in ALGS}
    fig, axes = plt.subplots(2, 3, figsize=(7.2, 5.0))
    for i, (ax, ds) in enumerate(zip(axes.ravel(), DATASETS)):
        data = [A.vec(R[a], ds, key) for a in ALGS]
        bp = ax.boxplot(data, widths=0.62, patch_artist=True, showfliers=True,
                        medianprops=dict(color="black", lw=0.9), whiskerprops=dict(lw=0.6), capprops=dict(lw=0.6),
                        flierprops=dict(marker="o", ms=1.8, mfc="none", mec="#7F7F7F", mew=0.5),
                        boxprops=dict(lw=0.6))
        for patch, a in zip(bp["boxes"], ALGS):
            patch.set_facecolor(STYLE[a]["color"])
            patch.set_alpha(0.95 if a == "SBMOCSO" else 0.75)
            patch.set_edgecolor("black" if a == "SBMOCSO" else "#4D4D4D")
            if a == "SBMOCSO":
                patch.set_linewidth(1.1)
        ax.plot(range(1, len(ALGS) + 1), [np.nanmean(d) for d in data], ls="none", marker="D", ms=2.6,
                mfc="white", mec="black", mew=0.6, zorder=5)
        if key == "hv_tr":
            upper = np.concatenate([d for d, a in zip(data, ALGS) if a not in ("NSGA-II", "LMOCSO")])
            y_lo = np.floor((np.nanpercentile(upper, 1) - 0.01) / 0.05) * 0.05
            compressed_axis(ax, y_lo, 1.0, 0.3, 0.25)
            ticks = [t for t in (0.4, 0.6) if t < y_lo - 0.05] + list(np.round(np.arange(y_lo, 1.0 + 1e-9, 0.05), 2))
            ax.set_yticks(ticks)
            ax.set_yticklabels([f"{t:.1f}" if t < y_lo - 1e-9 else f"{t:.2f}" for t in ticks])
        ax.set_xticks(range(1, len(ALGS) + 1))
        ax.set_xticklabels(ALGS, rotation=60, ha="right", fontsize=7)
        ax.set_title(f"({'abcdef'[i]}) {SHORT[ds]}", loc="left", fontsize=9, pad=3)
        if i % 3 == 0:
            ax.set_ylabel(ylabel)
        clean(ax)
    fig.legend([Line2D([], [], color="black", lw=0.9),
                Line2D([], [], ls="none", marker="D", ms=3, mfc="white", mec="black")],
               ["median", "mean"], loc="upper right", ncol=2, frameon=False, fontsize=7.5, bbox_to_anchor=(0.99, 1.0))
    fig.tight_layout(rect=(0, 0, 1, 0.97), h_pad=1.2)
    fig.savefig(FIG / fname)
    plt.close(fig)


def fig_fronts():
    """Figure 5: training and test fronts in the run with the median selected-panel error of SBMOCSO."""
    shown = ["SparseEA", "AFSEA", "SBMOCSO"]
    R = {a: A.load("main", a) for a in shown}
    fig, axes = plt.subplots(2, 3, figsize=(7.2, 4.4))
    for ax, ds in zip(axes.ravel(), DATASETS):
        err = A.vec(R["SBMOCSO"], ds, "err_te")
        r = int(np.argsort(err, kind="stable")[len(err) // 2])
        for a, mk in zip(shown, ["s", "^", "o"]):
            rec, col = R[a][ds][r], STYLE[a]["color"]
            ft, fe = rec["front_tr"], rec["front_te"]
            nf = ft[:, 0] * 2000
            o = np.argsort(nf)
            ax.plot(nf[o], ft[o, 1], marker=mk, ms=3, lw=0.9, color=col, label=f"{a} (training)")
            ax.plot(nf[o], fe[o, 1], marker=mk, ms=3, lw=0.9, ls="--", color=col, mfc="white", label=f"{a} (test)")
        ax.set_xscale("log")
        ax.minorticks_off()
        ax.set_xticks([1, 2, 5, 10, 20])
        ax.xaxis.set_major_formatter(matplotlib.ticker.ScalarFormatter())
        ax.set_ylim(-0.02, 0.8)
        ax.set_title(f"{SHORT[ds]} (run {r})")
        ax.set_xlabel("Number of selected genes")
        ax.set_ylabel("Balanced error")
    h, lab = axes[0, 0].get_legend_handles_labels()
    fig.legend(h, lab, loc="lower center", ncol=3, frameon=False, fontsize=7)
    fig.tight_layout(rect=(0, 0.1, 1, 1))
    fig.savefig(FIG / "fronts.pdf")
    plt.close(fig)


def fig_panel_size():
    """Figure 6: number of genes in the selected panel at 10,000 evaluations."""
    R = {a: A.load("main", a) for a in ALGS}
    fig, ax = plt.subplots(figsize=(7.2, 2.7))
    pos, data, cols = [], [], []
    for j, a in enumerate(ALGS):
        for k, ds in enumerate(DATASETS):
            data.append(np.maximum(A.vec(R[a], ds, "nfeat"), 1))
            pos.append(j * 7.5 + k)
            cols.append(a)
    bp = ax.boxplot(data, positions=pos, widths=0.8, patch_artist=True, showfliers=False,
                    medianprops=dict(color="black", lw=0.8), whiskerprops=dict(lw=0.5), capprops=dict(lw=0.5),
                    boxprops=dict(lw=0.5))
    for patch, a in zip(bp["boxes"], cols):
        patch.set_facecolor(STYLE[a]["color"])
        patch.set_alpha(0.8)
    ax.set_yscale("log")
    ax.set_yticks([1, 3, 10, 30, 100, 300, 1000])
    ax.set_yticklabels(["1", "3", "10", "30", "100", "300", "1000"])
    ax.set_xticks([j * 7.5 + 2.5 for j in range(len(ALGS))])
    ax.set_xticklabels(ALGS, fontsize=8)
    ax.set_ylabel("Genes in selected panel")
    clean(ax)
    fig.tight_layout()
    fig.savefig(FIG / "panel_size.pdf")
    plt.close(fig)


def _mean_curves(R, ds):
    out = {}
    for a in ALGS:
        curves = [r["curve"] for r in R[a][ds] if r is not None and len(r["curve"])]
        if not curves:
            continue
        ks = sorted(set.intersection(*[set(c[:, 0].astype(int)) for c in curves]))
        C = np.array([[c[c[:, 0] == k, 1][0] for k in ks] for c in curves])
        se = C.std(0, ddof=1) / np.sqrt(len(C))
        out[a] = (np.array(ks) / 20 * 10000, C.mean(0), 1.96 * se)
    return out


def fig_convergence():
    """Figure 7: mean training HV against the number of evaluations at a budget of 10,000."""
    R = {a: A.load("main", a) for a in ALGS}
    fig, axes = plt.subplots(2, 3, figsize=(7.2, 5.0))
    fig.subplots_adjust(left=0.085, right=0.985, bottom=0.09, top=0.885, wspace=0.30, hspace=0.36)
    for i, (ax, ds) in enumerate(zip(axes.ravel(), DATASETS)):
        M = _mean_curves(R, ds)
        top = np.concatenate([y[x > SCORING_END] for a, (x, y, _) in M.items() if a not in ("NSGA-II", "LMOCSO")])
        y_lo = np.floor((top.min() - 0.01) / 0.05) * 0.05
        y_hi = min(1.0, np.ceil((top.max() + 0.008) / 0.05) * 0.05)
        compressed_axis(ax, y_lo, y_hi, 0.30, 0.27)
        ax.axvspan(0, SCORING_END, color="#F2F2F2", lw=0, zorder=0)
        for a, (x, y, ci) in M.items():
            st = STYLE[a]
            if a == "SBMOCSO":
                ax.fill_between(x, y - ci, y + ci, color=st["color"], alpha=0.22, lw=0, zorder=4)
            ax.plot(x, y, color=st["color"], ls=st["ls"], lw=st["lw"], zorder=5 if a == "SBMOCSO" else 3,
                    solid_capstyle="round")
            if a == "SBMOCSO":
                ax.plot(x[1::2], y[1::2], ls="none", marker="o", ms=2.6, mfc="white", mec=st["color"], mew=0.9,
                        zorder=6)
        ticks = [t for t in (0.4, 0.6) if t < y_lo - 0.04] + list(np.arange(y_lo, y_hi + 1e-9, 0.05))
        ax.set_yticks(ticks)
        ax.set_yticklabels([f"{t:.1f}" if t < y_lo - 1e-9 else f"{t:.2f}" for t in ticks])
        clean(ax)
        ax.set_xlim(0, 10000)
        ax.set_xticks(range(0, 10001, 2000))
        ax.set_xticklabels(["0", "2k", "4k", "6k", "8k", "10k"])
        ax.set_title(f"({'abcdef'[i]}) {SHORT[ds]}", loc="left", fontsize=9, pad=3)
        if i % 3 == 0:
            ax.set_ylabel("Training hypervolume")
        if i // 3 == 1:
            ax.set_xlabel("Function evaluations", labelpad=2)
    sb = STYLE["SBMOCSO"]
    handles = [Line2D([], [], color=STYLE[a]["color"], ls=STYLE[a]["ls"], lw=STYLE[a]["lw"]) for a in ALGS[:-1]]
    handles.append((Patch(color=sb["color"], alpha=0.22, lw=0),
                    Line2D([], [], color=sb["color"], lw=sb["lw"], marker="o", ms=2.6, mfc="white",
                           mec=sb["color"], mew=0.9)))
    handles.append(Patch(facecolor="#F2F2F2", edgecolor="#BDBDBD", lw=0.5))
    labels = ALGS[:-1] + ["SBMOCSO, mean and 95% CI", "Single-gene scoring stage"]
    fig.legend(handles, labels, loc="upper center", ncol=6, frameon=False, fontsize=7.5,
               bbox_to_anchor=(0.53, 0.995), handlelength=2.4, columnspacing=1.1, handletextpad=0.5)
    fig.savefig(FIG / "convergence.pdf")
    plt.close(fig)


def fig_rank_budget():
    """Figure 8: mean rank of every algorithm against the evaluation budget."""
    budgets = [2000, 5000, 10000, 20000]
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.9), sharey=True)
    for ax, (key, lb, title) in zip(axes, (("hv_tr", True, "(a) Training hypervolume"),
                                         ("err_te", False, "(b) Selected-panel error"))):
        ranks = {b: A.compare_all(A.BUDGET_TAG[b], key, lb)["mean_rank"] for b in budgets}
        for a in ALGS:
            st, prop = STYLE[a], a == "SBMOCSO"
            ax.plot(range(4), [ranks[b][a] for b in budgets], color=st["color"], ls=st["ls"],
                    lw=st["lw"] + (0.4 if prop else 0), marker="o", ms=3.2 if prop else 2.4,
                    mfc="white" if prop else st["color"], mec=st["color"], zorder=5 if prop else 3, label=a)
        ax.set_xticks(range(4))
        ax.set_xticklabels(["2000", "5000", "10,000", "20,000"])
        ax.set_xlabel("Evaluation budget")
        ax.set_ylim(9.5, 0.5)
        ax.set_yticks(range(1, 10))
        ax.set_title(title, loc="left", fontsize=9, pad=3)
        clean(ax)
    axes[0].set_ylabel("Mean rank over six datasets")
    h, lab = axes[0].get_legend_handles_labels()
    fig.legend(h, lab, loc="lower center", ncol=9, frameon=False, fontsize=7, handlelength=2.2, columnspacing=0.9)
    fig.tight_layout(rect=(0, 0.1, 1, 1))
    fig.savefig(FIG / "rank_budget.pdf")
    plt.close(fig)


def fig_budget(key="err_te", ylabel="Selected-panel error"):
    """Figure 9: mean selected-panel error against the evaluation budget."""
    budgets = [2000, 5000, 10000, 20000]
    data = {b: {a: A.load(A.BUDGET_TAG[b], a) for a in ALGS} for b in budgets}
    fig, axes = plt.subplots(2, 3, figsize=(7.2, 4.4))
    for ax, ds in zip(axes.ravel(), DATASETS):
        for a in ALGS:
            st = STYLE[a]
            y = np.array([np.nanmean(A.vec(data[b][a], ds, key)) for b in budgets])
            if a == "SBMOCSO":
                ci = np.array([1.96 * np.nanstd(v, ddof=1) / np.sqrt(np.sum(~np.isnan(v)))
                               for v in (A.vec(data[b][a], ds, key) for b in budgets)])
                ax.fill_between(budgets, y - ci, y + ci, color=st["color"], alpha=0.18, lw=0, zorder=1)
            ax.plot(budgets, y, marker="o", ms=3, lw=st["lw"], ls=st["ls"], color=st["color"],
                    zorder=5 if a == "SBMOCSO" else 3, label=a)
        ax.set_xscale("log")
        ax.minorticks_off()
        ax.set_xticks(budgets)
        ax.set_xticklabels(["2k", "5k", "10k", "20k"])
        ax.set_title(SHORT[ds])
        ax.set_xlabel("Evaluation budget")
        ax.set_ylabel(ylabel)
    h, lab = axes[0, 0].get_legend_handles_labels()
    fig.legend(h, lab, loc="lower center", ncol=5, frameon=False, fontsize=7.5)
    fig.tight_layout(rect=(0, 0.09, 1, 1))
    fig.savefig(FIG / "budget.pdf")
    plt.close(fig)


def main():
    set_style()
    FIG.mkdir(parents=True, exist_ok=True)
    fig_boxes("err_te", "Selected-panel error", "dist_err.pdf")
    fig_boxes("hv_tr", "Training hypervolume", "dist_hv.pdf")
    fig_fronts()
    fig_panel_size()
    fig_convergence()
    fig_rank_budget()
    fig_budget()
    print("figures written to", FIG)


if __name__ == "__main__":
    main()
