"""All runs of the paper.

usage:
    python scripts/run_all.py --list > jobs.txt          # one run_one.py command line per run
    python scripts/run_all.py --workers 32               # run everything locally in parallel
    python scripts/run_all.py --workers 32 --group main  # only one group of runs

Groups:
    main      nine algorithms, 10,000 evaluations                         -> results/main
    budget    nine algorithms, 2000, 5000 and 20,000 evaluations          -> results/budget<B>
    ablation  three SBMOCSO variants, 2000, 5000 and 10,000 evaluations   -> results/ablation<B>/<variant>
    credit    SBMOCSO with feature credit, all four budgets               -> results/<tag>/SBMOCSO-credit
Runs whose result file already exists are skipped.
"""
from __future__ import annotations

import argparse
import json
import shlex
import sys
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))

from run_one import run_one  # noqa: E402
from sbmocso.algorithms import MODULES  # noqa: E402
from sbmocso.problem import DATASETS  # noqa: E402

RUNS = range(30)
BUDGET_TAG = {2000: "budget2000", 5000: "budget5000", 10000: "main", 20000: "budget20000"}
VARIANTS = {"uniformInit": {"init": "uniform"}, "fullCopy": {"full_copy": True}, "noMutation": {"mutate": False}}


def jobs(groups):
    """(algorithm, dataset, run, max_fe, tag, name, params) for every run of the selected groups."""
    out = []
    for ds in DATASETS:
        for r in RUNS:
            if "main" in groups:
                out += [(a, ds, r, 10000, "main", a, {}) for a in MODULES]
            if "budget" in groups:
                out += [(a, ds, r, b, BUDGET_TAG[b], a, {}) for b in (2000, 5000, 20000) for a in MODULES]
            if "ablation" in groups:
                out += [("SBMOCSO", ds, r, b, f"ablation{b}/{v}", "SBMOCSO", p)
                        for b in (2000, 5000, 10000) for v, p in VARIANTS.items()]
            if "credit" in groups:
                out += [("SBMOCSO", ds, r, b, BUDGET_TAG[b], "SBMOCSO-credit", {"credit": True})
                        for b in (2000, 5000, 10000, 20000)]
    return out


def done(job):
    a, ds, r, _, tag, name, _ = job
    return (ROOT / "results" / tag / name / ds / f"r{r}.npz").exists()


def command(job):
    a, ds, r, b, tag, name, p = job
    opts = " ".join(shlex.quote(f"{k}={json.dumps(v)}") for k, v in p.items())
    return f"python scripts/run_one.py {a} {ds} {r} {b} --tag {tag} --name {name} {opts}".rstrip()


def _run(job):
    a, ds, r, b, tag, name, p = job
    return run_one(a, ds, r, b, tag, name, p)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--group", nargs="*", default=["main", "budget", "ablation", "credit"],
                    choices=["main", "budget", "ablation", "credit"])
    ap.add_argument("--workers", type=int, default=1)
    ap.add_argument("--list", action="store_true", help="print the command lines and exit")
    a = ap.parse_args()
    pending = [j for j in jobs(a.group) if not done(j)]
    if a.list:
        print("\n".join(command(j) for j in pending))
        return
    print(f"{len(pending)} runs")
    with ProcessPoolExecutor(max_workers=a.workers) as ex:
        for f in as_completed([ex.submit(_run, j) for j in pending]):
            print(f.result(), flush=True)


if __name__ == "__main__":
    main()
