"""Database check of the genes selected by SBMOCSO (Section 2.8, Table S3 part A and Figure 10).

usage:
    python scripts/gene_check.py counts --gene-info Homo_sapiens.gene_info.gz
    python scripts/gene_check.py opentargets
    python scripts/gene_check.py test
    python scripts/gene_check.py figure

counts       gene-level selection counts over the 30 selected panels of SBMOCSO at 10,000 evaluations: a
             panel counts once for a gene when it contains any of its probes; probes without a gene
             symbol are separate units. Symbols and Ensembl identifiers come from the NCBI gene_info
             file (https://ftp.ncbi.nlm.nih.gov/gene/DATA/GENE_INFO/Mammalia/Homo_sapiens.gene_info.gz).
opentargets  association scores of all targets of the four diseases from the Open Targets Platform; the
             scores used in the paper (data release 26.09) are provided in data/gene_check and are used
             when this step has not been run.
test         one-sided permutation test of the mean overall association score of the genes selected in
             at least 2 panels against random candidate genes with an Ensembl identifier, Holm adjustment
             over the six datasets, pooled stratified test, and the test without the top-scoring gene.
figure       selection frequencies of the genes selected in at least 2 panels (Figure 10).
Output: output/gene_check/
"""
from __future__ import annotations

import argparse
import gzip
import json
import sys
import time
import urllib.request
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import analysis as A  # noqa: E402

from sbmocso.problem import DATA_DIR  # noqa: E402

OUT = A.OUT / "gene_check"
SNAPSHOT = A.ROOT / "data" / "gene_check"   # Open Targets data release 26.09, downloaded on 4 November 2026
DISEASE = {"AMD-RPE-GSE29801": "MONDO_0005150", "AMD-RET-GSE29801": "MONDO_0005150",
           "UM-GSE22138": "MONDO_0006486", "UM-GSE44295": "MONDO_0006486",
           "TED-GSE58331": "EFO_1001466", "DR-GSE160306": "MONDO_0005266"}
OT_URL = "https://api.platform.opentargets.org/api/v4/graphql"
OT_QUERY = """query($id:String!,$i:Int!){ disease(efoId:$id){ id name associatedTargets(page:{index:$i,size:3000}){
  count rows{ target{ id approvedSymbol } score datatypeScores{ id score } } } } }"""
MIN_COUNT, N_PERM, PERM_SEED = 2, 10000, 20261104
# result of the literature check (Table S3 part B): data source of the prior report
LITERATURE = {"CA12": "partly same", "AHNAK2": "partly same", "HNMT": "other", "EDNRB": "other", "KLB": "same"}


def counts(gene_info):
    sym2ens, ens2sym, syn2sym = {}, {}, {}
    for line in gzip.open(gene_info, "rt"):
        if line.startswith("#"):
            continue
        f = line.rstrip("\n").split("\t")
        ens = [x.split(":", 1)[1] for x in f[5].split("|") if x.startswith("Ensembl:")]
        if ens:
            sym2ens[f[2]] = ens[0]
            for e in ens:
                ens2sym.setdefault(e, f[2])
        for s in f[4].split("|"):
            if s != "-":
                syn2sym.setdefault(s, f[2])
    R = A.load("main", "SBMOCSO")
    out = {}
    for ds in A.DATASETS:
        d = np.load(DATA_DIR / f"{ds}.npz", allow_pickle=True)
        sym, feat = d["sym"], d["feat"]
        probes = []
        for j in range(len(feat)):
            if str(feat[j]).startswith("ENSG"):
                ens = str(feat[j])
                s = ens2sym.get(ens, "")
            else:
                s = str(sym[j]).split("///")[0].strip() if sym[j] else ""
                s = s if s in sym2ens else syn2sym.get(s, s)
                ens = sym2ens.get(s, "")
            probes.append(dict(feat=str(feat[j]), symbol=s, ensembl=ens))
        unit = [p["symbol"] if p["symbol"] else "probe " + p["feat"] for p in probes]
        idx = {}
        for j, u in enumerate(unit):
            idx.setdefault(u, []).append(j)
        cnt = {u: sum(bool(rec["mask_best"][js].any()) for rec in R[ds] if rec is not None) for u, js in idx.items()}
        units = sorted(({"name": u, "count": cnt[u], "n_probes": len(js), "has_symbol": not u.startswith("probe "),
                         "ensembl": next((probes[j]["ensembl"] for j in js if probes[j]["ensembl"]), "")}
                        for u, js in idx.items()), key=lambda u: (-u["count"], u["name"]))
        third = units[2]["count"]
        out[ds] = dict(units=units, top3=[u for u in units if u["count"] >= third])
        print(ds, ", ".join(f"{u['name']} ({u['count']})" for u in out[ds]["top3"]))
    (OUT / "genes.json").write_text(json.dumps(out))


def opentargets():
    for did in sorted(set(DISEASE.values())):
        rows, i = [], 0
        while True:
            req = urllib.request.Request(OT_URL, headers={"Content-Type": "application/json"},
                                         data=json.dumps({"query": OT_QUERY, "variables": {"id": did, "i": i}}).encode())
            with urllib.request.urlopen(req, timeout=120) as r:
                d = json.loads(r.read())["data"]["disease"]["associatedTargets"]
            rows += d["rows"]
            if len(rows) >= d["count"] or not d["rows"]:
                break
            i += 1
            time.sleep(0.5)
        (OUT / f"opentargets_{did}.json").write_text(json.dumps(rows))
        print(did, "targets:", len(rows))


def _perm_p(score, cand, rng):
    k, obs = int(cand.sum()), score[cand].mean()
    null = np.array([score[rng.choice(len(score), k, replace=False)].mean() for _ in range(N_PERM)])
    return obs, null, float((1 + np.sum(null >= obs)) / (N_PERM + 1))


def test():
    G = json.loads((OUT / "genes.json").read_text())
    ot = {}
    for d in set(DISEASE.values()):
        f = OUT / f"opentargets_{d}.json"
        f = f if f.exists() else SNAPSHOT / f"opentargets_{d}.json"
        ot[d] = {r["target"]["id"]: r["score"] for r in json.loads(f.read_text())}
    rng = np.random.default_rng(PERM_SEED)
    res, pooled_obs, pooled_null = {}, 0.0, np.zeros(N_PERM)
    for ds in A.DATASETS:
        bg = [u for u in G[ds]["units"] if u["ensembl"]]
        score = np.array([ot[DISEASE[ds]].get(u["ensembl"], 0.0) for u in bg])
        cand = np.array([u["count"] >= MIN_COUNT for u in bg])
        obs, null, p = _perm_p(score, cand, rng)
        k = int(cand.sum())
        pooled_obs += score[cand].sum()
        pooled_null += null * k
        order = np.argsort(-np.where(cand, score, -1))
        keep = np.ones(len(bg), bool)
        keep[order[0]] = False
        _, _, p_drop = _perm_p(score[keep], cand[keep], rng)
        res[ds] = dict(disease=DISEASE[ds], n_candidate_genes=len(bg), n_selected=k,
                       n_assoc_selected=int((score[cand] > 0).sum()), frac_assoc_all=float((score > 0).mean()),
                       mean_score_selected=float(obs), mean_score_all=float(score.mean()), p=p,
                       top_gene=bg[order[0]]["name"], p_without_top=p_drop)
    adj = A.holm([res[ds]["p"] for ds in A.DATASETS])
    for ds, a in zip(A.DATASETS, adj):
        res[ds]["p_holm"] = float(a)
    res["pooled_p"] = float((1 + np.sum(pooled_null >= pooled_obs)) / (N_PERM + 1))
    for ds in A.DATASETS:
        r = res[ds]
        print(f"{A.SHORT[ds]:8s} selected {r['n_selected']:2d}, associated {r['n_assoc_selected']}, mean score "
              f"{r['mean_score_selected']:.3f} vs {r['mean_score_all']:.3f}, p = {r['p']:.3f}, Holm p = {r['p_holm']:.3f}, "
              f"without {r['top_gene']}: p = {r['p_without_top']:.3f}")
    print(f"pooled p = {res['pooled_p']:.3f}")
    (OUT / "opentargets_test.json").write_text(json.dumps(res, indent=1))


def figure():
    import matplotlib.pyplot as plt
    from matplotlib.patches import Patch

    import figures as F
    F.set_style()
    G = json.loads((OUT / "genes.json").read_text())
    colors = {"other": "#D55E00", "partly same": "#E8A07A", "same": "#BDBDBD", None: "#7F96B2"}
    fig, axes = plt.subplots(2, 3, figsize=(7.2, 4.9))
    for i, (ax, ds) in enumerate(zip(axes.ravel(), A.DATASETS)):
        units = [u for u in G[ds]["units"] if u["count"] >= MIN_COUNT][:12][::-1]
        ax.barh(range(len(units)), [u["count"] for u in units], height=0.7, edgecolor="none",
                color=[colors[LITERATURE.get(u["name"])] for u in units])
        ax.set_yticks(range(len(units)))
        ax.set_yticklabels([u["name"] for u in units], fontsize=6.6)
        ax.axvline(min(u["count"] for u in G[ds]["top3"]) - 0.5, color="#9E9E9E", lw=0.6, ls=(0, (3, 2)))
        ax.set_xlim(0, 9)
        ax.set_xticks([0, 2, 4, 6, 8])
        ax.set_title(f"({'abcdef'[i]}) {A.SHORT[ds]}", loc="left", fontsize=9, pad=3)
        if i // 3 == 1:
            ax.set_xlabel("Selected panels (of 30)")
        F.clean(ax, grid=False)
    labels = ["prior report on other data", "prior report partly on the same series", "prior report on the same series",
              "no prior report or not searched"]
    fig.legend([Patch(color=colors[k]) for k in ("other", "partly same", "same", None)], labels,
               loc="lower center", ncol=2, frameon=False, fontsize=7.2)
    fig.tight_layout(rect=(0, 0.08, 1, 1), w_pad=1.0)
    (A.OUT / "figures").mkdir(parents=True, exist_ok=True)
    fig.savefig(A.OUT / "figures" / "gene_freq.pdf")
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("step", choices=["counts", "opentargets", "test", "figure"])
    ap.add_argument("--gene-info", type=Path, help="NCBI Homo_sapiens.gene_info.gz (step counts)")
    a = ap.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    if a.step == "counts":
        if a.gene_info is None:
            ap.error("--gene-info is required for the step counts")
        counts(a.gene_info)
    else:
        {"opentargets": opentargets, "test": test, "figure": figure}[a.step]()


if __name__ == "__main__":
    main()
