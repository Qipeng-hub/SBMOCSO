#!/usr/bin/env python3
"""OpenAlex literature search for the three most frequent genes of each dataset (ties included).

usage: python scripts/gene_literature.py [--mailto ADDRESS] [--out FILE]

Every name of a gene (symbol, full name, alias) is combined with every disease term in an OpenAlex
title and abstract search. A work is kept when its title or abstract contains the gene name as a whole
word and one of the disease terms; the abstracts are stored so that each hit can be read.
Output: output/gene_check/openalex_hits.json
"""
import argparse
import datetime
import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

DISEASE_TERMS = {
    "AMD": ["macular degeneration"],
    "UM": ["uveal melanoma", "choroidal melanoma"],
    "TED": ["thyroid eye disease", "Graves ophthalmopathy", "Graves orbitopathy", "thyroid-associated ophthalmopathy"],
    "DR": ["diabetic retinopathy"],
}
# text match for the disease (title or abstract, case-insensitive)
DISEASE_MATCH = {
    "AMD": ["macular degeneration"],
    "UM": ["uveal melanoma", "choroidal melanoma", "ocular melanoma"],
    "TED": ["thyroid eye disease", "ophthalmopathy", "orbitopathy"],
    "DR": ["diabetic retinopathy", "diabetic macular"],
}
# three most frequent genes of each dataset with ties (output/gene_check/genes.json, step counts)
GENES = [
    # dataset, disease, symbol, other names
    ("AMD-RPE", "AMD", "GAS1", ["growth arrest-specific 1", "growth arrest specific 1"]),
    ("AMD-RET", "AMD", "PDE6C", ["phosphodiesterase 6C"]),
    ("AMD-RET", "AMD", "SNHG17", []),
    ("UM-1", "UM", "CA12", ["carbonic anhydrase XII", "carbonic anhydrase 12", "CAXII", "CA XII"]),
    ("UM-1", "UM", "GALNT18", []),
    ("UM-1", "UM", "AHNAK2", []),
    ("UM-1", "UM", "CYRIB", ["FAM49B"]),
    ("UM-1", "UM", "HNMT", ["histamine N-methyltransferase"]),
    ("UM-1", "UM", "IFIT1", []),
    ("UM-1", "UM", "SLC1A4", ["ASCT1"]),
    ("UM-1", "UM", "TCEAL2", []),
    ("UM-2", "UM", "ABCB4", ["MDR3"]),
    ("UM-2", "UM", "DIPK2A", ["C3orf58"]),
    ("UM-2", "UM", "EDNRB", ["endothelin receptor type B", "endothelin B receptor", "ETB receptor"]),
    ("UM-2", "UM", "LHB", ["luteinizing hormone beta"]),
    ("UM-2", "UM", "MAP3K13", ["LZK"]),
    ("UM-2", "UM", "NAALADL1", []),
    ("TED", "TED", "CD24", []),
    ("TED", "TED", "F13A1", ["factor XIII-A", "factor XIII A"]),
    ("TED", "TED", "KLB", ["beta-Klotho", "β-Klotho"]),
    ("TED", "TED", "MAB21L2", []),
    ("DR", "DR", "PAWR", ["Par-4", "prostate apoptosis response-4", "prostate apoptosis response 4"]),
    ("DR", "DR", "RGS5", ["regulator of G protein signaling 5", "regulator of G-protein signaling 5"]),
    ("DR", "DR", "NEU4", ["neuraminidase 4", "sialidase 4"]),
    ("DR", "DR", "ZNF728", []),
]


def get(url, ua, retries=4):
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": ua})
            with urllib.request.urlopen(req, timeout=40) as r:
                return json.loads(r.read())
        except urllib.error.HTTPError as e:
            if e.code == 429 and attempt < retries - 1:
                time.sleep(5 * (attempt + 1))
                continue
            raise
    return None


def abstract(w):
    inv = w.get("abstract_inverted_index") or {}
    pos = {p: t for t, ps in inv.items() for p in ps}
    return " ".join(pos[i] for i in sorted(pos))


def name_pattern(name):
    flags = re.I if len(name) > 6 else 0          # short symbols are matched case-sensitively
    return re.compile(r"(?<![A-Za-z0-9-])" + re.escape(name) + r"(?![A-Za-z0-9-])", flags)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mailto", default=None)
    ap.add_argument("--out", default=str(Path(__file__).resolve().parents[1] / "output" / "gene_check" / "openalex_hits.json"))
    ap.add_argument("--per-page", default="50")
    args = ap.parse_args()
    ua = "gene-evidence-check" + (f" (mailto:{args.mailto})" if args.mailto else "")
    result = {"date": datetime.date.today().isoformat(), "source": "OpenAlex title_and_abstract.search", "genes": []}
    for ds, dis, sym, aliases in GENES:
        names = [sym] + aliases
        seen, hits, queries = set(), [], []
        for nm in names:
            for dq in DISEASE_TERMS[dis]:
                params = {"filter": f'title_and_abstract.search:"{nm}" {dq}', "per-page": args.per_page,
                          "select": "id,doi,title,publication_year,primary_location,abstract_inverted_index,cited_by_count,type"}
                if args.mailto:
                    params["mailto"] = args.mailto
                url = "https://api.openalex.org/works?" + urllib.parse.urlencode(params)
                try:
                    data = get(url, ua)
                except Exception as e:
                    queries.append({"name": nm, "disease": dq, "error": str(e)})
                    print(f"  ERROR {sym} {nm} {dq}: {e}")
                    continue
                queries.append({"name": nm, "disease": dq, "count": data.get("meta", {}).get("count")})
                pat = name_pattern(nm)
                for w in data.get("results", []):
                    if w["id"] in seen:
                        continue
                    text = (w.get("title") or "") + " " + abstract(w)
                    if not pat.search(text):
                        continue
                    if not any(t.lower() in text.lower().replace("'", "") for t in DISEASE_MATCH[dis]):
                        continue
                    seen.add(w["id"])
                    src = ((w.get("primary_location") or {}).get("source") or {}).get("display_name")
                    hits.append({"matched_name": nm, "openalex_id": w["id"], "doi": w.get("doi"), "title": w.get("title"),
                                 "year": w.get("publication_year"), "venue": src, "type": w.get("type"),
                                 "cited_by": w.get("cited_by_count"), "abstract": abstract(w)})
                time.sleep(0.25)
        result["genes"].append({"dataset": ds, "disease": dis, "symbol": sym, "names": names,
                                "queries": queries, "n_hits": len(hits), "hits": hits})
        print(f"{ds:8s} {sym:9s} hits {len(hits)}")
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=1)
    print("written", args.out)


if __name__ == "__main__":
    main()
