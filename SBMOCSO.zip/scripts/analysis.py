"""Statistics and tables of the paper from the run results.

usage: python scripts/analysis.py

Reads results/<tag>/<algorithm>/<dataset>/r<run>.npz and writes
    output/tables/*.tex   LaTeX table bodies (Tables 4-9, S1 and S2)
    output/summary.json   all values used in the text
Comparisons: for each dataset, SBMOCSO against every other algorithm by a two-sided Wilcoxon
signed-rank test paired by run, Holm adjustment over the comparisons of a dataset, alpha = 0.05.
Mean ranks over the six datasets are tested with the Friedman test.
"""
from __future__ import annotations

import functools
import json
import sys
from pathlib import Path

import numpy as np
from scipy.stats import friedmanchisquare, rankdata, wilcoxon

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from sbmocso.problem import DATASETS  # noqa: E402

RESULTS = ROOT / "results"
OUT = ROOT / "output"
TAB = OUT / "tables"
ALGS = ["NSGA-II", "SparseEA", "PM-MOEA", "MSKEA", "SparseEA2", "AFSEA", "LMOCSO", "S-ECSO", "SBMOCSO"]
SPARSE = ["SparseEA", "PM-MOEA", "MSKEA", "SparseEA2", "AFSEA"]
OTHER = ["NSGA-II", "LMOCSO", "S-ECSO"]
SHORT = {"AMD-RPE-GSE29801": "AMD-RPE", "AMD-RET-GSE29801": "AMD-RET", "UM-GSE22138": "UM-1",
         "UM-GSE44295": "UM-2", "TED-GSE58331": "TED", "DR-GSE160306": "DR"}
BUDGET_TAG = {2000: "budget2000", 5000: "budget5000", 10000: "main", 20000: "budget20000"}
VARIANTS = {"uniformInit": "Uniform size initialization", "fullCopy": "Full copy of the winner",
            "noMutation": "Without sparse mutation"}
RUNS = range(30)
ALPHA = 0.05


@functools.lru_cache(maxsize=None)
def load(tag, alg):
    """Per dataset, a list of 30 run records (None for a missing run).

    err_te is the selected-panel error: the test error of the non-dominated panel with the lowest
    training error (ties broken by the smaller panel).
    """
    out = {}
    for ds in DATASETS:
        recs = []
        for r in RUNS:
            f = RESULTS / tag / alg / ds / f"r{r}.npz"
            if not f.exists():
                recs.append(None)
                continue
            d = np.load(f)
            nd = d["nd"]
            tro = d["tr_obj"][nd]
            te = d["te_err"][nd]
            best = np.argmin(tro[:, 1] + 1e-9 * tro[:, 0])
            masks = np.unpackbits(d["masks"], axis=1)[:, : int(d["D"])].astype(bool)[nd]
            recs.append(dict(hv_te=float(d["hv_test"]), hv_tr=float(d["hv_train"]), cpu=float(d["cpu"]),
                             nfeat=float(tro[best, 0] * int(d["D"])), err_tr=float(tro[best, 1]),
                             err_te=float(te[best]), curve=d["curve"], mask_best=masks[best],
                             front_tr=tro, front_te=np.column_stack([tro[:, 0], te]), fes=int(d["fes"])))
        out[ds] = recs
    return out


def vec(R, ds, key):
    return np.array([r[key] if r is not None else np.nan for r in R[ds]])


def wilcoxon_p(R1, R2, ds, key):
    x, y = vec(R1, ds, key), vec(R2, ds, key)
    ok = ~np.isnan(x) & ~np.isnan(y)
    x, y = x[ok], y[ok]
    if len(x) < 5 or np.all(x == y):
        return 1.0
    return float(wilcoxon(x, y).pvalue)


def holm(pvals):
    """Holm-adjusted p values, in the order of the input."""
    p = np.asarray(pvals, float)
    order = np.argsort(p)
    adj = np.empty_like(p)
    running, m = 0.0, len(p)
    for i, k in enumerate(order):
        running = max(running, (m - i) * p[k])
        adj[k] = min(1.0, running)
    return adj


def marker(R1, R2, ds, key, p, larger_better=True):
    """'+' if R1 is significantly better than R2, '-' if significantly worse, '=' otherwise."""
    if p >= ALPHA:
        return "="
    x, y = vec(R1, ds, key), vec(R2, ds, key)
    d = np.median(x - y)
    if d == 0:
        d = np.nanmean(x - y)
    return "+" if (d > 0 if larger_better else d < 0) else "-"


def fmt_budget(b):
    return f"{b:,}".replace(",", "{,}") if b >= 10000 else str(b)


def compare_all(tag, key, larger_better=True, fname=None, digits=3):
    """SBMOCSO against the eight other algorithms on one indicator; optionally writes the table body."""
    R = {a: load(tag, a) for a in ALGS}
    prop, others = ALGS[-1], ALGS[:-1]
    ranks, wtl, cells, stats = [], {a: [0, 0, 0] for a in others}, {a: [] for a in ALGS}, {}
    for ds in DATASETS:
        means = np.array([np.nanmean(vec(R[a], ds, key)) for a in ALGS])
        stds = np.array([np.nanstd(vec(R[a], ds, key), ddof=1) for a in ALGS])
        rk = rankdata(-means if larger_better else means)
        ranks.append(rk)
        raw = [wilcoxon_p(R[prop], R[a], ds, key) for a in others]
        adj = dict(zip(others, holm(raw)))
        for i, a in enumerate(ALGS):
            s = f"{means[i]:.{digits}f} ({stds[i]:.{digits}f})"
            if rk[i] == rk.min():
                s = r"\textbf{" + s + "}"
            if a != prop:
                m = marker(R[prop], R[a], ds, key, adj[a], larger_better)
                wtl[a]["+=-".index(m)] += 1
                stats.setdefault(ds, {})[a] = dict(marker=m, p_holm=float(adj[a]))
                s += {"+": r" $+$", "-": r" $-$", "=": r" $\approx$"}[m]
            cells[a].append(s)
    mr = np.mean(ranks, axis=0)
    if fname:
        rows = []
        for i, a in enumerate(ALGS):
            w = "--" if a == prop else "/".join(map(str, wtl[a]))
            r = (r"\textbf{%.2f}" % mr[i]) if mr[i] == mr.min() else f"{mr[i]:.2f}"
            rows.append(a + " & " + " & ".join(cells[a]) + f" & {w} & {r}" + r" \\")
        (TAB / fname).write_text("\n".join(rows) + "\n")
    return dict(mean_rank=dict(zip(ALGS, mr.round(3).tolist())), wtl=wtl,
                friedman_p=float(friedmanchisquare(*np.array(ranks).T).pvalue), stats=stats,
                means={ds: {a: float(np.nanmean(vec(R[a], ds, key))) for a in ALGS} for ds in DATASETS})


def main_tables():
    """Tables 4-6: selected-panel error, training HV and test HV at 10,000 evaluations."""
    return dict(selected_err=compare_all("main", "err_te", False, "main_selected_err.tex"),
                train_hv=compare_all("main", "hv_tr", True, "main_train_hv.tex"),
                test_hv=compare_all("main", "hv_te", True, "main_test_hv.tex"))


def budget_table():
    """Table 7: mean rank and grouped +/=/- counts of SBMOCSO at every budget."""
    out, rows = {}, []
    for b, tag in BUDGET_TAG.items():
        cells = []
        for key, lb in (("err_te", False), ("hv_tr", True), ("hv_te", True)):
            r = compare_all(tag, key, lb)
            groups = {name: [sum(r["wtl"][a][i] for a in grp) for i in range(3)]
                      for name, grp in (("sparse", SPARSE), ("other", OTHER))}
            mr = r["mean_rank"]
            sb = load(tag, "SBMOCSO")
            mean_value = float(np.mean([np.nanmean(vec(sb, ds, key)) for ds in DATASETS]))
            out[f"{b}_{key}"] = dict(rank=mr["SBMOCSO"], mean_value=mean_value, friedman_p=r["friedman_p"],
                                     mean_rank=mr, groups=groups, per_algorithm=r["wtl"])
            cells += [f"{mr['SBMOCSO']:.2f} ({mean_value:.3f})", "/".join(map(str, groups["sparse"])),
                      "/".join(map(str, groups["other"]))]
        rows.append(fmt_budget(b) + " & " + " & ".join(cells) + r" \\")
    (TAB / "budget.tex").write_text("\n".join(rows) + "\n")
    return out


def ablation_table(keys=("err_te", "hv_tr")):
    """Table 8: SBMOCSO against its three variants, Holm adjustment over the variants of a dataset."""
    res, out, rows = {}, {}, []
    for B in (2000, 5000, 10000):
        full = load(BUDGET_TAG[B], "SBMOCSO")
        RV = {v: load(f"ablation{B}/{v}", "SBMOCSO") for v in VARIANTS}
        for key in keys:
            lb = key != "err_te"
            w = {v: [0, 0, 0] for v in VARIANTS}
            diffs = {v: [] for v in VARIANTS}
            for ds in DATASETS:
                adj = holm([wilcoxon_p(full, RV[v], ds, key) for v in VARIANTS])
                for v, pa in zip(VARIANTS, adj):
                    w[v]["+=-".index(marker(full, RV[v], ds, key, pa, lb))] += 1
                    diffs[v].append(np.nanmean(vec(full, ds, key) - vec(RV[v], ds, key)))
            for v in VARIANTS:
                res[(v, B, key)] = (w[v], float(np.mean(diffs[v])))
    for v, label in VARIANTS.items():
        cells = []
        for B in (2000, 5000, 10000):
            for key in keys:
                w, d = res[(v, B, key)]
                d = 0.0 if abs(d) < 5e-4 else d
                cells.append(f"{w[0]}/{w[1]}/{w[2]} ({d:+.3f})".replace("(+0.000)", "(0.000)"))
                out.setdefault(label, {})[f"{B}_{key}"] = dict(wtl=w, mean_diff=res[(v, B, key)][1])
        rows.append(label + " & " + " & ".join(cells) + r" \\")
    (TAB / "ablation.tex").write_text("\n".join(rows) + "\n")
    return out


def credit_table(keys=("err_te", "hv_tr", "hv_te")):
    """Table S2: SBMOCSO against the credit variant, paired Wilcoxon test without correction."""
    out, rows = {}, []
    for b, tag in BUDGET_TAG.items():
        S, C = load(tag, "SBMOCSO"), load(tag, "SBMOCSO-credit")
        cells = []
        for key in keys:
            lb = key != "err_te"
            w, d = [0, 0, 0], []
            for ds in DATASETS:
                w["+=-".index(marker(S, C, ds, key, wilcoxon_p(S, C, ds, key), lb))] += 1
                d.append(np.nanmean(vec(S, ds, key) - vec(C, ds, key)))
            cells.append(f"{w[0]}/{w[1]}/{w[2]} ({np.mean(d):+.3f})".replace("(-0.000)", "(0.000)")
                         .replace("(+0.000)", "(0.000)"))
            out[f"{b}_{key}"] = dict(wtl=w, mean_diff=float(np.mean(d)))
        rows.append(fmt_budget(b) + " & " + " & ".join(cells) + r" \\")
    (TAB / "credit.tex").write_text("\n".join(rows) + "\n")
    return out


def runtime_and_size_tables():
    """Table 9 (CPU time) and Table S1 (genes / selected-panel error) at 10,000 evaluations."""
    R = {a: load("main", a) for a in ALGS}
    info, rows_t, rows_s = {}, [], []
    for ds in DATASETS:
        for a in ALGS:
            info.setdefault(ds, {})[a] = {k: float(np.nanmean(vec(R[a], ds, k)))
                                          for k in ("cpu", "nfeat", "err_te", "err_tr", "fes")}
        rows_t.append(SHORT[ds] + " & " + " & ".join(f"{info[ds][a]['cpu']:.1f}" for a in ALGS) + r" \\")
        rows_s.append(SHORT[ds] + " & " + " & ".join(f"{info[ds][a]['nfeat']:.1f} / {info[ds][a]['err_te']:.3f}"
                                                      for a in ALGS) + r" \\")
    (TAB / "runtime.tex").write_text("\n".join(rows_t) + "\n")
    (TAB / "size_error.tex").write_text("\n".join(rows_s) + "\n")
    return info


def main():
    TAB.mkdir(parents=True, exist_ok=True)
    S = dict(main=main_tables(), budget=budget_table(), ablation=ablation_table(), credit=credit_table(),
             runtime_size=runtime_and_size_tables())
    (OUT / "summary.json").write_text(json.dumps(S, indent=1, default=float))
    print("tables written to", TAB)


if __name__ == "__main__":
    main()
