"""Run one algorithm on one dataset and one train/test split.

usage: python scripts/run_one.py ALGORITHM DATASET RUN MAX_FE [--tag TAG] [--name NAME] [key=value ...]

ALGORITHM is a key of sbmocso.algorithms.MODULES, DATASET one of sbmocso.problem.DATASETS, RUN the
split index (0-29 in the paper) and MAX_FE the evaluation budget. key=value pairs override algorithm
options; values are read as JSON when possible and as strings otherwise (e.g. init=uniform full_copy=true
mutate=false).
The result is written to results/TAG/NAME/DATASET/r<RUN>.npz (NAME defaults to ALGORITHM).
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import numpy as np  # noqa: E402

from sbmocso import algorithms  # noqa: E402
from sbmocso.core import MOTask  # noqa: E402
from sbmocso.metrics import hv2d, nondominated  # noqa: E402
from sbmocso.problem import DATASETS, GeneSelection  # noqa: E402

POP_SIZE = 100
N_CHECKPOINTS = 20


def algorithm_seed(dataset, run):
    return 5_000_000 + 10007 * DATASETS.index(dataset) + 101 * int(run)


def run_one(alg_name, dataset, run, max_fe, tag="main", name=None, params=None, results_dir=None):
    params = params or {}
    mod = algorithms.get(alg_name)
    problem = GeneSelection(dataset, run, mod.CODING)
    seed = algorithm_seed(dataset, run)
    task = MOTask(problem, N=POP_SIZE, max_fes=max_fe, seed=seed, n_save=N_CHECKPOINTS)
    t0 = time.process_time()
    res = mod.run(task, **{**algorithms.defaults(alg_name), **params})
    cpu = time.process_time() - t0

    masks = problem.masks(res.decs)
    tr_obj = res.objs
    te_err = problem.test_error(res.decs)
    te_obj = np.column_stack([tr_obj[:, 0], te_err])
    # non-dominated solutions of the final population on the training objectives
    F = nondominated(tr_obj)
    nd = np.array([np.any(np.all(np.isclose(F, o), axis=1)) for o in tr_obj], dtype=bool)
    # checkpoint index, training HV, and the number of evaluations at which the checkpoint was taken
    curve = [(k, hv2d(p.objs), fe) for (k, p), fe in zip(task.history, task.history_fe)]

    out = Path(results_dir or ROOT / "results") / tag / (name or alg_name) / dataset
    out.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(out / f"r{run}.npz", masks=np.packbits(masks, axis=1), D=problem.D, tr_obj=tr_obj,
                        te_err=te_err, nd=nd, hv_train=hv2d(tr_obj[nd]), hv_test=hv2d(te_obj[nd]),
                        curve=np.array(curve, float), fes=res.fes, cpu=cpu, seed=seed,
                        params=json.dumps(params))
    return f"{name or alg_name} {dataset} r{run} FE={res.fes} hv_train={hv2d(tr_obj[nd]):.4f} " \
           f"hv_test={hv2d(te_obj[nd]):.4f} cpu={cpu:.1f}s"


def _value(text):
    """JSON value of an option; text that is not valid JSON is taken as a string."""
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return text


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("algorithm", choices=list(algorithms.MODULES))
    ap.add_argument("dataset", choices=DATASETS)
    ap.add_argument("run", type=int)
    ap.add_argument("max_fe", type=int)
    ap.add_argument("--tag", default="main")
    ap.add_argument("--name", default=None)
    ap.add_argument("options", nargs="*", help="key=value algorithm options (JSON values)")
    a = ap.parse_args(argv)
    params = {k: _value(v) for k, v in (o.split("=", 1) for o in a.options)}
    print(run_one(a.algorithm, a.dataset, a.run, a.max_fe, a.tag, a.name, params))


if __name__ == "__main__":
    main()
