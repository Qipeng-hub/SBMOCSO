"""Build the six gene selection datasets from the files of the Gene Expression Omnibus (GEO).

usage: python scripts/prepare_data.py [AMD-RPE AMD-RET UM1 UM2 TED DR]

Input files in data/raw (download from https://www.ncbi.nlm.nih.gov/geo/):
    GSE29801, GSE22138, GSE44295, GSE58331, GSE160306: <GSE>_series_matrix.txt.gz
    GSE160306_human_retina_DR_totalRNA_normalized_cpm.txt.gz (supplementary file of GSE160306)
    GPL4133.annot.gz, GPL570.annot.gz, GPL6883.annot.gz (platform annotations)

Output: data/processed/<NAME>.npz with
    X        (n, D) float32, log2 expression of the D most variable features (labels not used)
    y        (n,) int8, 1 = case
    groups   (n,) donor / patient identifier (splits keep a donor on one side)
    feat     (D,) probe / Ensembl identifiers, sym (D,) gene symbols ('' if unknown)
    samples  (n,) GSM accessions or sample IDs
The variance filter does not use the labels and is applied once per dataset.
"""
from __future__ import annotations

import gzip
import json
import re
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
OUT = ROOT / "data" / "processed"
D_KEEP = 2000


def read_series_matrix(gse):
    meta, rows, ids = {}, [], []
    in_table = False
    with gzip.open(RAW / f"{gse}_series_matrix.txt.gz", "rt", errors="replace") as fh:
        for line in fh:
            line = line.rstrip("\n")
            if line.startswith("!series_matrix_table_begin"):
                in_table = True
                header = None
                continue
            if line.startswith("!series_matrix_table_end"):
                break
            if in_table:
                p = [x.strip('"') for x in line.split("\t")]
                if header is None:
                    header = p
                    continue
                ids.append(p[0])
                rows.append([float(x) if x not in ("", "null", "NA", "NaN") else np.nan for x in p[1:]])
            elif line.startswith("!Sample_"):
                p = line.split("\t")
                k = p[0]
                v = [x.strip('"') for x in p[1:]]
                meta.setdefault(k, []).append(v)
    X = np.array(rows, dtype=float).T          # samples x probes
    return header[1:], np.array(ids), X, meta


def char_field(meta, key):
    """Per-sample value of the characteristic 'key: value', searched in all characteristic rows."""
    out = None
    for row in meta.get("!Sample_characteristics_ch1", []):
        vals = [v.split(": ", 1)[1] if v.lower().startswith(key.lower() + ": ") else None for v in row]
        if out is None:
            out = vals
        else:
            out = [a if a is not None else b for a, b in zip(out, vals)]
    return out


def annot_symbols(gpl):
    sym = {}
    with gzip.open(RAW / f"{gpl}.annot.gz", "rt", errors="replace") as fh:
        header = None
        for line in fh:
            if line.startswith("#") or line.startswith("!") or line.startswith("^"):
                continue
            p = line.rstrip("\n").split("\t")
            if header is None:
                header = p
                i_id, i_sym = header.index("ID"), header.index("Gene symbol")
                continue
            if len(p) > i_sym:
                sym[p[i_id]] = p[i_sym]
    return sym


def finish(name, X, y, groups, feat, sym, samples, info):
    X = np.asarray(X, dtype=float)
    keep = np.all(np.isfinite(X), axis=0)
    X, feat, sym = X[:, keep], feat[keep], sym[keep]
    if np.nanmax(X) > 100:                      # intensities that are not yet on a log2 scale
        X = np.log2(np.maximum(X, 0) + 1.0)
    var = X.var(axis=0)
    top = np.argsort(-var, kind="stable")[:D_KEEP]
    top = np.sort(top)
    X, feat, sym = X[:, top], feat[top], sym[top]
    OUT.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(OUT / f"{name}.npz", X=X.astype(np.float32), y=np.asarray(y, dtype=np.int8),
                        groups=np.asarray(groups).astype(str), feat=np.asarray(feat).astype(str),
                        sym=np.asarray(sym).astype(str), samples=np.asarray(samples).astype(str))
    info.update(n=int(len(y)), n_pos=int(np.sum(y)), n_neg=int(len(y) - np.sum(y)),
                n_groups=int(len(set(groups))), D=int(X.shape[1]), value_range=[float(X.min()), float(X.max())])
    print(name, json.dumps(info))
    return info


GSE29801_EXCLUDE = {"GSM738635", "GSM738676"}


def gse29801(tissue_src, name):
    gsm, probes, X, meta = read_series_matrix("GSE29801")
    src = meta["!Sample_source_name_ch1"][0]
    pid = char_field(meta, "patient identifier")
    # GSM738635 (normal donor IA039-98) and GSM738676 (AMD donor IA090-98) are near-identical arrays
    # (Pearson r = 0.998 after log2(x+1), 0.99998 on the deposited values) with conflicting labels; both are excluded
    sel = [i for i, s in enumerate(src) if s.startswith(tissue_src) and gsm[i] not in GSE29801_EXCLUDE]
    y = np.array([1 if src[i].endswith("AMD") else 0 for i in sel])
    sym = annot_symbols("GPL4133")
    return finish(name, X[sel], y, [pid[i] for i in sel], probes, np.array([sym.get(p, "") for p in probes]),
                  [gsm[i] for i in sel], dict(gse="GSE29801", tissue=tissue_src, label="AMD vs normal"))


def gse22138():
    gsm, probes, X, meta = read_series_matrix("GSE22138")
    met = char_field(meta, "metastasis")
    sel = [i for i, m in enumerate(met) if m in ("yes", "no")]
    y = np.array([1 if met[i] == "yes" else 0 for i in sel])
    sym = annot_symbols("GPL570")
    return finish("UM-GSE22138", X[sel], y, [gsm[i] for i in sel], probes,
                  np.array([sym.get(p, "") for p in probes]), [gsm[i] for i in sel],
                  dict(gse="GSE22138", label="metastasis yes vs no (primary uveal melanoma)"))


def gse44295():
    gsm, probes, X, meta = read_series_matrix("GSE44295")
    ct = char_field(meta, "cell type")
    met = char_field(meta, "metastasis")
    sel = [i for i in range(len(gsm)) if ct[i] == "primary uveal melanoma cells" and met[i] in ("0", "1")]
    y = np.array([int(met[i]) for i in sel])
    sym = annot_symbols("GPL6883")
    return finish("UM-GSE44295", X[sel], y, [gsm[i] for i in sel], probes,
                  np.array([sym.get(p, "") for p in probes]), [gsm[i] for i in sel],
                  dict(gse="GSE44295", label="metastasis 1 vs 0 (primary uveal melanoma cells)"))


def gse58331():
    gsm, probes, X, meta = read_series_matrix("GSE58331")
    dx = char_field(meta, "diagnosis")
    tis = char_field(meta, "tissue")
    sel = [i for i in range(len(gsm)) if dx[i] in ("TED", "Normal") and tis[i] == "Anterior Orbit"]
    y = np.array([1 if dx[i] == "TED" else 0 for i in sel])
    # several samples come from the same subject (e.g. "TED Anterior Orbit 22_22AGr" and "..22_22BGr",
    # technical replicates "26.1"/"26.2"): the subject is the diagnosis plus the number in the title
    title = meta["!Sample_title"][0]
    subject = []
    for i in sel:
        m = re.match(r"^(TED|Normal) Anterior Orbit (\d+)(?=[ _])", title[i])
        assert m and m.group(1) == dx[i], title[i]
        subject.append(f"{m.group(1)}_{m.group(2)}")
    sym = annot_symbols("GPL570")
    return finish("TED-GSE58331", X[sel], y, subject, probes,
                  np.array([sym.get(p, "") for p in probes]), [gsm[i] for i in sel],
                  dict(gse="GSE58331", tissue="anterior orbit", label="thyroid eye disease vs normal"))


def gse160306():
    gsm, _, _, meta = read_series_matrix("GSE160306")
    sid = char_field(meta, "sampleID")
    donor = char_field(meta, "donor")
    grp = char_field(meta, "disease_group")
    with gzip.open(RAW / "GSE160306_human_retina_DR_totalRNA_normalized_cpm.txt.gz", "rt") as fh:
        header = fh.readline().rstrip("\n").split(",")
        ens, rows = [], []
        for line in fh:
            p = line.rstrip("\n").split(",")
            ens.append(p[0])
            rows.append([float(v) for v in p[1:]])
    M = np.array(rows).T
    col = {s: i for i, s in enumerate(header[1:])}
    sel = [i for i in range(len(gsm)) if sid[i] in col]
    X = M[[col[sid[i]] for i in sel]]
    y = np.array([1 if grp[i] in ("NPDR", "PDR") else 0 for i in sel])
    return finish("DR-GSE160306", X, y, [donor[i] for i in sel], np.array(ens), np.array([""] * len(ens)),
                  [gsm[i] for i in sel], dict(gse="GSE160306", tissue="retina macula + periphery",
                                               label="NPDR/PDR (incl. DME) vs no DR (control + diabetic)"))


if __name__ == "__main__":
    which = sys.argv[1:] or ["all"]
    infos = {}
    jobs = {
        "AMD-RPE": lambda: gse29801("Macular RPE-choroid", "AMD-RPE-GSE29801"),
        "AMD-RET": lambda: gse29801("Macular Retina", "AMD-RET-GSE29801"),
        "UM1": gse22138, "UM2": gse44295, "TED": gse58331, "DR": gse160306,
    }
    for k, f in jobs.items():
        if "all" in which or k in which:
            infos[k] = f()
    if "all" in which:
        (OUT / "datasets.json").write_text(json.dumps(infos, indent=1))
