"""MSKEA (Ding et al., 2022), following the PlatEMO implementation.

A variable-score vector pv obtained from the D single-variable solutions, a variable-fluctuation vector
fv and a selection vector sv (selection frequency in the first front) guide mask crossover and mutation
in three stages: the pv/fv operator while FE/maxFE < 0.618^2, either operator with probability 0.5 while
FE/maxFE < 0.618, and the sv operator afterwards. Environmental selection removes duplicated objective
vectors and truncates the last front as in SPEA2. The single-variable evaluations count toward the budget.
"""
from __future__ import annotations

import math

import numpy as np

from ..core import Pop
from ..operators import CrowdingDistance, NDSort, OperatorGAhalf, TournamentSelection, unifrnd, unique_rows
from .pmmoea import _truncation

NAME = "MSKEA"
YEAR = 2022
REFERENCE = ("Z. Ding, L. Chen, D. Sun, and X. Zhang. A multi-stage knowledge-guided evolutionary algorithm "
             "for sparse multi-objective optimization problems. Swarm and Evolutionary Computation, 2022, "
             "73: 101119.")
CODING = "binary"
DEFAULTS: dict = {}


def _std0(X):
    """std(X,0,1): sqrt(sum((x-mean).^2)/(n-1)), n = 1 -> 0; sequential sums as MATLAB."""
    n = X.shape[0]
    if n == 0:
        return np.full(X.shape[1], np.nan)
    if n == 1:
        return np.zeros(X.shape[1])
    mu = np.cumsum(X, axis=0)[-1] / n
    return np.sqrt(np.cumsum(np.abs(X - mu) ** 2, axis=0)[-1] / (n - 1))


def _ts(fit, rng):
    """TS of Operator_pvfv.m: one binary-tournament index (0-based) or None if empty."""
    if len(fit) == 0:
        return None
    return int(TournamentSelection(2, 1, fit, rng=rng)[0])


def spea2_environmental_selection(pop: Pop, Dec, Mask, N):
    """SPEA2_EnvironmentalSelection.m."""
    _, uni, _ = unique_rows(pop.objs)              # sorted order, first occurrences
    pop = pop[uni]
    Dec = Dec[uni]
    Mask = Mask[uni]
    N = min(N, len(pop))
    FrontNo, MaxFNo = NDSort(pop.objs, N)
    Next = FrontNo < MaxFNo

    PopObj = pop.objs
    f1 = FrontNo == 1
    fmax = np.max(PopObj[f1], axis=0)
    fmin = np.min(PopObj[f1], axis=0)
    with np.errstate(divide="ignore", invalid="ignore"):
        PopObj = (PopObj - fmin) / (fmax - fmin)

    Last = np.flatnonzero(FrontNo == MaxFNo)
    dele = _truncation(PopObj[Last], len(Last) - N + int(Next.sum()))
    Next[Last[~dele]] = True
    pop = pop[Next]
    Dec = Dec[Next]
    Mask = Mask[Next]
    FrontNo = FrontNo[Next]
    CrowdDis = CrowdingDistance(pop.objs, FrontNo)
    return pop, Dec, Mask, FrontNo, CrowdDis


def _off_dec(task, ParentDec, rng):
    enc = task.encoding
    if np.any(enc != 4):
        OffDec = OperatorGAhalf(task, ParentDec, rng=rng)
        OffDec[:, enc == 4] = 1
    else:
        OffDec = np.ones((ParentDec.shape[0] // 2, ParentDec.shape[1]))
    return OffDec


def operator_pvfv(task, ParentDec, ParentMask, pv, fv, delta, rng):
    """Operator_pvfv.m."""
    N, D = ParentDec.shape
    h = N // 2
    Parent1Mask = ParentMask[:h]
    Parent2Mask = ParentMask[h:]

    # Crossover for mask
    OffMask = Parent1Mask.copy()
    for i in range(h):
        if rng.random() < 0.5:
            index = np.flatnonzero(Parent1Mask[i] & ~Parent2Mask[i])
            k = _ts(-pv[index], rng)
            if k is not None:
                OffMask[i, index[k]] = 0
        else:
            index = np.flatnonzero(~Parent1Mask[i] & Parent2Mask[i])
            k = _ts(pv[index], rng)
            if k is not None:
                OffMask[i, index[k]] = Parent2Mask[i, index[k]]

    # Mutation for mask
    if rng.random() < (1 - delta):
        f_vector = fv.copy()
        f_vector[fv > 0] = 1
        for i in range(h):
            index = np.flatnonzero(OffMask[i] != f_vector)
            if rng.random() < 0.5:
                k = _ts(-fv[index], rng)
                if k is not None:
                    OffMask[i, index[k]] = 1
            else:
                k = _ts(fv[index], rng)
                if k is not None:
                    OffMask[i, index[k]] = 0
    else:
        for i in range(h):
            if rng.random() < 0.5:
                index = np.flatnonzero(OffMask[i])
                k = _ts(-pv[index], rng)
                if k is not None:
                    OffMask[i, index[k]] = 0
            else:
                index = np.flatnonzero(~OffMask[i])
                k = _ts(pv[index], rng)
                if k is not None:
                    OffMask[i, index[k]] = 1

    return _off_dec(task, ParentDec, rng), OffMask


def operator_sv(task, ParentDec, ParentMask, sv, rng):
    """Operator_sv.m."""
    N, D = ParentDec.shape
    h = N // 2
    Parent1Mask = ParentMask[:h]
    Parent2Mask = ParentMask[h:]

    # Crossover for mask
    OffMask = Parent1Mask.copy()
    rate0 = sv                 # probability that 0 inverts to 1
    rate1 = 1 - rate0          # probability that 1 inverts to 0
    for i in range(h):
        diff = np.flatnonzero(Parent1Mask[i] != Parent2Mask[i])
        o = OffMask[i, diff]
        rate = np.where(o, rate1[diff], rate0[diff])
        exchange = rng.random(diff.size) < rate
        OffMask[i, diff[exchange]] = ~OffMask[i, diff[exchange]]

    # Mutation for mask
    Mutation_p = 1 / D
    Mu_exchange = rng.random((h, D)) < Mutation_p
    for i in range(h):
        if Mu_exchange[i].sum():
            subscript = np.flatnonzero(Mu_exchange[i])
            o = OffMask[i, subscript]
            rate = np.where(o, rate1[subscript], rate0[subscript])
            exchange = rng.random(subscript.size) < rate
            OffMask[i, subscript[exchange]] = ~OffMask[i, subscript[exchange]]

    return _off_dec(task, ParentDec, rng), OffMask


def run(task, **params):
    rng = task.rng
    N, D = task.N, task.D
    enc = task.encoding
    lo, up = task.lower, task.upper

    # pv and population initialization
    TDec, TMask, TempPop = [], [], []
    pv = np.zeros(D)
    for _ in range(1 + 4 * int(np.any(enc != 4))):
        Dec = unifrnd(np.tile(lo, (D, 1)), np.tile(up, (D, 1)), rng=rng)
        Dec[:, enc == 4] = 1
        Mask = np.eye(D, dtype=bool)
        P = task.evaluate(Dec * Mask)
        TDec.append(Dec)
        TMask.append(Mask)
        TempPop.append(P)
        pv = pv + NDSort(np.hstack([P.objs, P.cons]), np.inf)[0]
    Dec = unifrnd(np.tile(lo, (N, 1)), np.tile(up, (N, 1)), rng=rng)
    Dec[:, enc == 4] = 1
    Mask = np.zeros((N, D), bool)

    # Mask initialization by pv
    for i in range(N):
        Mask[i, TournamentSelection(2, math.ceil(rng.random() * D), pv, rng=rng)] = True
    pop = task.evaluate(Dec * Mask)
    pop, Dec, Mask, FrontNo, CrowdDis = spea2_environmental_selection(
        Pop.cat(pop, *TempPop), np.vstack([Dec] + TDec), np.vstack([Mask] + TMask), N)
    sv = np.zeros(D)
    Last_temp_num = 0
    fv = None

    # Optimization
    while task.not_terminated(pop):
        MatingPool = TournamentSelection(2, 2 * N, FrontNo, -CrowdDis, rng=rng)
        # update fv
        delta = task.FE / task.max_fes
        f1 = FrontNo == 1
        if delta < 0.618:
            fv = _std0(pop.decs[f1])
            fv[enc == 4] = Mask[f1][:, enc == 4].sum(axis=0)
        # update sv
        First_Mask = Mask[f1]
        temp_num = First_Mask.shape[0]
        temp_vote = First_Mask.sum(axis=0)
        sv = (Last_temp_num / (Last_temp_num + temp_num)) * sv + \
             (temp_num / (Last_temp_num + temp_num)) * (temp_vote / temp_num)
        Last_temp_num = temp_num
        # update pv by sv
        if delta < 0.618:
            pv = pv * (1 - sv) * math.sqrt(delta) + pv
        if (delta / 0.618) < 0.618:
            OffDec, OffMask = operator_pvfv(task, Dec[MatingPool], Mask[MatingPool], pv, fv, delta, rng)
        elif (delta / 0.618) >= 0.618 and delta < 0.618:
            if rng.random() < 0.5:
                OffDec, OffMask = operator_sv(task, Dec[MatingPool], Mask[MatingPool], sv, rng)
            else:
                OffDec, OffMask = operator_pvfv(task, Dec[MatingPool], Mask[MatingPool], pv, fv, delta, rng)
        else:
            OffDec, OffMask = operator_sv(task, Dec[MatingPool], Mask[MatingPool], sv, rng)
        off = task.evaluate(OffDec * OffMask)
        pop, Dec, Mask, FrontNo, CrowdDis = spea2_environmental_selection(
            Pop.cat(pop, off), np.vstack([Dec, OffDec]), np.vstack([Mask, OffMask]), N)
    return task.result()
