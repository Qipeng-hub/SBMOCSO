"""NSGA-II (Deb et al., 2002), following the PlatEMO implementation."""
from __future__ import annotations

import numpy as np

from ..core import Pop
from ..operators import CrowdingDistance, NDSort, OperatorGA, TournamentSelection, msort

NAME = "NSGA-II"
YEAR = 2002
REFERENCE = ("K. Deb, A. Pratap, S. Agarwal, and T. Meyarivan. A fast and elitist multiobjective genetic "
             "algorithm: NSGA-II. IEEE Transactions on Evolutionary Computation, 2002, 6(2): 182-197.")
CODING = "binary"
DEFAULTS: dict = {}


def environmental_selection(pop: Pop, N: int):
    FrontNo, MaxFNo = NDSort(pop.objs, pop.cons, N)
    Next = FrontNo < MaxFNo
    CrowdDis = CrowdingDistance(pop.objs, FrontNo)
    Last = np.where(FrontNo == MaxFNo)[0]
    _, Rank = msort(CrowdDis[Last], True)
    Next[Last[Rank[:N - int(Next.sum())]]] = True
    return pop[Next], FrontNo[Next], CrowdDis[Next]


def run(task, **params):
    pop = task.initialization()
    pop, FrontNo, CrowdDis = environmental_selection(pop, task.N)
    while task.not_terminated(pop):
        mating = TournamentSelection(2, task.N, FrontNo, -CrowdDis, rng=task.rng)
        off = OperatorGA(task, pop[mating])
        pop, FrontNo, CrowdDis = environmental_selection(Pop.cat(pop, off), task.N)
    return task.result()
