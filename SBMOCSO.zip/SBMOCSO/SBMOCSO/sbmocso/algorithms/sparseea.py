"""SparseEA (Tian et al., 2020), following the PlatEMO implementation.

Each solution is a real or binary vector Dec multiplied by a binary Mask. The decision variables are
scored by evaluating the D single-variable solutions (five times when a variable is not binary); these
evaluations count toward the budget and enter the first environmental selection.
"""
from __future__ import annotations

import math

import numpy as np

from ..core import Pop
from ..operators import (CrowdingDistance, NDSort, OperatorGAhalf, TournamentSelection, msort, unifrnd,
                         unique_rows)

NAME = "SparseEA"
YEAR = 2020
REFERENCE = ("Y. Tian, X. Zhang, C. Wang, and Y. Jin. An evolutionary algorithm for large-scale sparse "
             "multi-objective optimization problems. IEEE Transactions on Evolutionary Computation, 2020, "
             "24(2): 380-393.")
CODING = "binary"
DEFAULTS: dict = {}


def environmental_selection(pop: Pop, Dec, Mask, N: int):
    """EnvironmentalSelection.m of SparseEA (also used by SparseEA2, identical file)."""
    # Delete duplicated solutions
    _, uni, _ = unique_rows(pop.objs)
    pop, Dec, Mask = pop[uni], Dec[uni], Mask[uni]
    N = min(N, len(pop))
    # Non-dominated sorting
    FrontNo, MaxFNo = NDSort(pop.objs, pop.cons, N)
    Next = FrontNo < MaxFNo
    # Crowding distance
    CrowdDis = CrowdingDistance(pop.objs, FrontNo)
    # Last front by crowding distance
    Last = np.flatnonzero(FrontNo == MaxFNo)
    _, Rank = msort(CrowdDis[Last], True)
    Next[Last[Rank[:N - int(Next.sum())]]] = True
    return pop[Next], Dec[Next], Mask[Next], FrontNo[Next], CrowdDis[Next]


def ts(fit, rng):
    """Operator.m local TS: binary tournament of one index among `fit` (empty -> empty)."""
    if len(fit) == 0:
        return np.zeros(0, dtype=int)
    return TournamentSelection(2, 1, fit, rng=rng)


def variable_scores(task):
    """Score every decision variable (SparseEA.m 'Calculate the fitness of each decision variable')."""
    D = task.D
    TDec, TMask, TempPop = [], [], []
    Fitness = np.zeros(D)
    for _ in range(1 + 4 * int(np.any(task.encoding != 4))):
        Dec = unifrnd(np.tile(task.lower, (D, 1)), np.tile(task.upper, (D, 1)), rng=task.rng)
        Dec[:, task.encoding == 4] = 1
        Mask = np.eye(D, dtype=bool)
        pop = task.evaluate(Dec * Mask)
        TDec.append(Dec)
        TMask.append(Mask)
        TempPop.append(pop)
        Fitness = Fitness + NDSort(np.hstack([pop.objs, pop.cons]), np.inf)[0]
    return np.vstack(TDec), np.vstack(TMask), Pop.cat(*TempPop), Fitness


def initial_population(task, Fitness):
    """Generate initial population (SparseEA.m)."""
    N, D = task.N, task.D
    Dec = unifrnd(np.tile(task.lower, (N, 1)), np.tile(task.upper, (N, 1)), rng=task.rng)
    Dec[:, task.encoding == 4] = 1
    Mask = np.zeros((N, D), dtype=bool)
    for i in range(N):
        k = math.ceil(task.rng.random() * D)
        Mask[i, TournamentSelection(2, k, Fitness, rng=task.rng)] = True
    return Dec, Mask


def operator(task, ParentDec, ParentMask, Fitness):
    """Operator.m of SparseEA."""
    rng = task.rng
    N, D = ParentDec.shape
    h = N // 2
    Parent1Mask = ParentMask[:h]
    Parent2Mask = ParentMask[h:]
    # Crossover for mask
    OffMask = Parent1Mask.copy()
    for i in range(h):
        if rng.random() < 0.5:
            index = np.flatnonzero(Parent1Mask[i] & ~Parent2Mask[i])
            index = index[ts(-Fitness[index], rng)]
            OffMask[i, index] = False
        else:
            index = np.flatnonzero(~Parent1Mask[i] & Parent2Mask[i])
            index = index[ts(Fitness[index], rng)]
            OffMask[i, index] = Parent2Mask[i, index]
    # Mutation for mask
    for i in range(h):
        if rng.random() < 0.5:
            index = np.flatnonzero(OffMask[i])
            index = index[ts(-Fitness[index], rng)]
            OffMask[i, index] = False
        else:
            index = np.flatnonzero(~OffMask[i])
            index = index[ts(Fitness[index], rng)]
            OffMask[i, index] = True
    # Crossover and mutation for dec
    if np.any(task.encoding != 4):
        OffDec = OperatorGAhalf(task, ParentDec, rng=rng)
        OffDec[:, task.encoding == 4] = 1
    else:
        OffDec = np.ones((h, D))
    return OffDec, OffMask


def run(task, **params):
    # Population initialization
    TDec, TMask, TempPop, Fitness = variable_scores(task)
    Dec, Mask = initial_population(task, Fitness)
    pop = task.evaluate(Dec * Mask)
    pop, Dec, Mask, FrontNo, CrowdDis = environmental_selection(
        Pop.cat(pop, TempPop), np.vstack([Dec, TDec]), np.vstack([Mask, TMask]), task.N)
    # Optimization
    while task.not_terminated(pop):
        MatingPool = TournamentSelection(2, 2 * task.N, FrontNo, -CrowdDis, rng=task.rng)
        OffDec, OffMask = operator(task, Dec[MatingPool], Mask[MatingPool], Fitness)
        off = task.evaluate(OffDec * OffMask)
        pop, Dec, Mask, FrontNo, CrowdDis = environmental_selection(
            Pop.cat(pop, off), np.vstack([Dec, OffDec]), np.vstack([Mask, OffMask]), task.N)
    return task.result()
