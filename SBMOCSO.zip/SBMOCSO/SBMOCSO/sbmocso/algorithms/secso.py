"""S-ECSO (Wang et al., 2022), following the PlatEMO implementation.

Implementation notes:
* The number of iterations is fixed to maxFE / (3N) - 1. As in PlatEMO, the last iteration is completed
  after the budget is reached; the number of evaluations actually used is returned in
  result.extra["fe_used"].
* The swarm and the archive are kept separately, and the archive is returned.
* Strongly convex sparse operator: x <- sign(x) * max(|x| - lambda, 0), where lambda decreases
  linearly from LMax * (upper - lower).
* Competitions are held among three sub-swarms of sizes floor(N/3), N - 2 floor(N/3) - 1 and
  floor(N/3) + 1.
"""
from __future__ import annotations

import numpy as np

from ..core import Pop
from ..operators import NDSort, pdist2, unique_rows

NAME = "S-ECSO"
YEAR = 2022
REFERENCE = ("X. Wang, K. Zhang, J. Wang, and Y. Jin. An enhanced competitive swarm optimizer with strongly "
             "convex sparse operator for large-scale multi-objective optimization. IEEE Transactions on "
             "Evolutionary Computation, 2022, 26(5): 859-871.")
CODING = "real"
DEFAULTS: dict = {"LMax": 0.35, "LMin": 0.0}


# ----------------------------------------------------------------------------- SCSparse.m
def sc_sparse(task, Population: Pop, L, rng):
    x = Population.decs
    row_x, col_x = x.shape
    new_x = np.zeros((row_x, col_x))
    for i in range(row_x):
        flag_T = L < np.abs(x[i])
        new_x[i, flag_T] = x[i, flag_T] - L[flag_T] * np.sign(x[i, flag_T])

    x_maxmin = task.upper - task.lower
    for irange in range(row_x):
        up = np.flatnonzero(task.upper < new_x[irange])
        if up.size:
            new_x[irange, up] = rng.random(up.size) * x_maxmin[up]
        lo = np.flatnonzero(task.lower > new_x[irange])
        if lo.size:
            new_x[irange, lo] = rng.random(lo.size) * x_maxmin[lo]

    newpop = task.evaluate(new_x)
    XX = Pop.cat(Population, newpop)
    N = len(newpop)
    FrontNo, _ = NDSort(XX.objs, np.inf)
    keep = FrontNo[N:] <= FrontNo[:N]                    # Population(i) = XX(i+N)
    decs, objs, cons = Population.decs.copy(), Population.objs.copy(), Population.cons.copy()
    decs[keep], objs[keep], cons[keep] = newpop.decs[keep], newpop.objs[keep], newpop.cons[keep]
    return Pop(decs, objs, cons)


# ----------------------------------------------------------------------------- A_get.m
def _truncation(PopObj, K):
    N = PopObj.shape[0]
    Distance = pdist2(PopObj, PopObj)
    np.fill_diagonal(Distance, np.inf)
    Del = np.zeros(N, bool)
    while Del.sum() < K:
        Remain = np.flatnonzero(~Del)
        Temp = np.sort(Distance[np.ix_(Remain, Remain)], axis=1)
        first = np.lexsort(Temp.T[::-1])[0]              # [~,Rank] = sortrows(Temp); Rank(1)
        Del[Remain[first]] = True
    return Del


def a_get(task, Population: Pop, A: Pop | None, it, rng):
    if it == 1:
        A = Pop.empty()
    CC = Pop.cat(A, Population)
    FrontNo, _ = NDSort(CC.objs, np.inf)
    AA = CC[FrontNo == 1]
    _, index, _ = unique_rows(AA.decs)
    AA = AA[index]

    # adding perturbation
    ELS_A = AA.decs.copy()
    D = ELS_A.shape[1]
    for i in range(ELS_A.shape[0]):
        j = int(np.ceil(rng.random() * D)) - 1
        ELS_A[i, j] = ELS_A[i, j] + (task.upper[j] - task.lower[j]) * rng.standard_normal()
        ELS_A[i, j] = min(max(ELS_A[i, j], task.lower[j]), task.upper[j])
    ELS_A1 = task.evaluate(ELS_A)

    # truncating (SPEA2)
    AA = Pop.cat(AA, ELS_A1)
    if len(AA) > task.N:
        FrontNo, MaxFNo = NDSort(AA.objs, task.N)
        Next = FrontNo < MaxFNo
        PopObj = AA.objs
        fmax = PopObj[FrontNo == 1].max(axis=0)
        fmin = PopObj[FrontNo == 1].min(axis=0)
        with np.errstate(invalid="ignore", divide="ignore"):
            PopObj = (PopObj - fmin) / (fmax - fmin)
        Last = np.flatnonzero(FrontNo == MaxFNo)
        dele = _truncation(PopObj[Last], len(Last) - task.N + int(Next.sum()))
        Next[Last[~dele]] = True
        AA = AA[Next]

    # gBest
    objs = AA.objs
    r = rng.random(objs.shape[1])
    f_gBest = np.sum(r[None, :] * objs, axis=1) / np.sum(r)
    gBest = AA.decs[int(np.argmin(f_gBest))]
    return AA, gBest


# ----------------------------------------------------------------------------- ECSO.m
def ecso(task, Population: Pop, v, gBest, si, rng):
    w, c1, c2 = 0.7968, 1.4962, 1.4962
    x = Population.decs.copy()
    v = v.copy()
    Obj = Population.objs
    n = x.shape[0]
    a, b, c = si[0] - 1, si[1] - 1, si[2] - 1               # 0-based starts of the sub-swarms
    bounds = [(a, b), (b, c), (c, n)]
    llBest = np.zeros_like(x)
    for (s, e) in bounds:
        FR, _ = NDSort(Obj[s:e], np.inf)
        subswa = x[s + np.flatnonzero(FR == 1)]
        lb = subswa[rng.integers(subswa.shape[0])]
        llBest[s:e] = lb
    n1, n2, n3 = b - a, c - b, n - c
    rs1 = rng.permutation(n1)
    rs2 = rng.permutation(n2) + n1
    rs3 = rng.permutation(n3) + n1 + n2
    sub_pair_size = n // 3
    Front_rank, _ = NDSort(Obj, np.inf)

    for i in range(sub_pair_size):
        trio = [rs1[i], rs2[i], rs3[i]]
        rrank = int(np.argmin(Front_rank[trio]))             # first minimum
        win = trio[rrank]
        l1, l2 = [t for k, t in enumerate(trio) if k != rrank]
        if rng.random() < 0.5:
            v[l1] = rng.random() * v[l1] + rng.random() * (x[win] - x[l1])
            x[l1] = x[l1] + v[l1]
            v[l2] = w * v[l2] + c1 * rng.random() * (llBest[l2] - x[l2]) + c2 * rng.random() * (gBest - x[l2])
            x[l2] = x[l2] + v[l2]
        else:
            v[l2] = rng.random() * v[l2] + rng.random() * (x[win] - x[l2])
            x[l2] = x[l2] + v[l2]
            v[l1] = w * v[l1] + c1 * rng.random() * (llBest[l1] - x[l1]) + c2 * rng.random() * (gBest - x[l1])
            x[l1] = x[l1] + v[l1]

    # Restrict the range
    x = np.minimum(x, task.upper[None, :])
    x = np.maximum(x, task.lower[None, :])
    return task.evaluate(x), v


# ----------------------------------------------------------------------------- SECSO.m
def run(task, LMax=0.35, LMin=0.0, **params):
    rng = task.rng
    N, D = task.N, task.D
    subswarm = N // 3
    subswarm_index = [1, 1 + subswarm, N - subswarm]     # MATLAB 1-based
    rangev = task.upper - task.lower
    step = (LMax - LMin) * rangev / ((task.max_fes / N / 3) - 1)
    lamb = LMax * rangev

    x = rng.random((N, D))
    v = rng.random((N, D))
    x = x * (task.upper - task.lower)[None, :] + task.lower[None, :]
    v = v * (task.upper - task.lower)[None, :] + task.lower[None, :]
    Population = task.evaluate(x)
    Population1 = Population                              # swarm; `Population` is the archive A

    it = 0
    fe_forced = None
    while task.not_terminated(Population):
        it += 1
        if it > task.max_fes / N / 3 - 1:
            fe_forced = task.FE                           # PlatEMO: Problem.FE = Problem.maxFE
            task.FE = task.max_fes
        Population1 = sc_sparse(task, Population1, lamb, rng)
        Population, gBest = a_get(task, Population1, Population, it, rng)
        Population1, v = ecso(task, Population1, v, gBest, subswarm_index, rng)
        lamb = lamb - step
    fe_used = task.FE if fe_forced is None else fe_forced + (task.FE - task.max_fes)
    return task.result(fe_used=int(fe_used), iterations=it)
