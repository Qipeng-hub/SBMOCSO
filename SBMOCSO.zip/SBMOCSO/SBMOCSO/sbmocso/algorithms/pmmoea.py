"""PM-MOEA (Tian et al., 2022), following the PlatEMO implementation.

In every generation, maximum and minimum sparse patterns (20 each) are mined from the masks of the first
front by a small bi-objective search. Offspring masks are produced by unbalanced binary crossover inside
a maximum pattern, with a minimum pattern switched on, followed by unbalanced mutation. Offspring that
repeat a current member are discarded before evaluation, so a generation may evaluate fewer than N/2
solutions. Survival uses SPEA2 truncation.

Implementation notes:
* Non-dominated sorting inside the pattern mining uses the ENS-SS procedure (`_ndsort_ens_ss`), because
  the mining objectives are NaN when a first-front mask is empty.
* The truncation reproduces the deletion order of the PlatEMO loop (stable lexicographic order, NaN last).
"""
from __future__ import annotations

import math

import numpy as np

from ..core import Pop
from ..operators import NDSort, OperatorGAhalf, TournamentSelection, pdist2, randperm, unifrnd, unique_rows

NAME = "PM-MOEA"
YEAR = 2022
REFERENCE = ("Y. Tian, C. Lu, X. Zhang, F. Cheng, and Y. Jin. A pattern mining based evolutionary algorithm "
             "for large-scale sparse multi-objective optimization problems. IEEE Transactions on "
             "Cybernetics, 2022, 52(7): 6784-6797.")
CODING = "binary"
DEFAULTS: dict = {}


# ----------------------------------------------------------------------------- helpers
def _lexmin_row(T):
    """Index of the first row of sortrows(T) (stable lexicographic order, NaN largest)."""
    cand = np.arange(T.shape[0])
    for c in range(T.shape[1]):
        if len(cand) == 1:
            break
        col = T[cand, c]
        ok = ~np.isnan(col)
        if not ok.any():
            continue                                  # all NaN: tie, keep order
        m = col[ok].min()
        cand = cand[col == m]                         # NaN never equals m
    return int(cand[0])


def _truncation(PopObj, K):
    """Truncation(PopObj,K) of EnvironmentalSelection.m: logical Del with K deleted rows."""
    PopObj = np.asarray(PopObj, dtype=float)
    n = PopObj.shape[0]
    Del = np.zeros(n, bool)
    if K <= 0:
        return Del
    Distance = pdist2(PopObj, PopObj)
    np.fill_diagonal(Distance, np.inf)
    order = np.argsort(Distance, axis=1, kind="stable")        # NaN last, as MATLAB sort
    S = np.take_along_axis(Distance, order, axis=1)
    while Del.sum() < K:
        Remain = np.flatnonzero(~Del)
        keep = ~Del[order[Remain]]                             # each row loses the same columns
        Temp = S[Remain][keep].reshape(len(Remain), -1)        # == sort(Distance(Remain,Remain),2)
        Del[Remain[_lexmin_row(Temp)]] = True
    return Del


def _ndsort_ens_ss(PopObj, nSort):
    """ENS-SS non-dominated sorting of PlatEMO (unconstrained), including its handling of NaN."""
    PopObj = np.asarray(PopObj, dtype=float)
    U, _, Loc = unique_rows(PopObj)                  # NaN rows stay distinct, as MATLAB unique
    Table = np.bincount(Loc, minlength=U.shape[0])
    N, M = U.shape
    FrontNo = np.full(N, np.inf)
    MaxFNo = 0
    target = min(nSort, len(Loc))
    while Table[FrontNo < np.inf].sum() < target:
        MaxFNo += 1
        for i in range(N):
            if FrontNo[i] != np.inf:
                continue
            Dominated = False
            for j in range(i - 1, -1, -1):
                if FrontNo[j] == MaxFNo:
                    m = 1
                    while m < M and U[i, m] >= U[j, m]:
                        m += 1
                    Dominated = m >= M
                    if Dominated or M == 2:
                        break
            if not Dominated:
                FrontNo[i] = MaxFNo
    return FrontNo[Loc], MaxFNo


def _ndsort(PopObj, nSort):
    if np.isnan(PopObj).any():
        return _ndsort_ens_ss(PopObj, nSort)
    return NDSort(PopObj, nSort)


def binary_crossover(Parent1, Parent2, rng):
    """BinaryCrossover.m (unbalanced binary crossover), row by row."""
    Parent1 = np.atleast_2d(Parent1)
    Parent2 = np.atleast_2d(Parent2)
    Offspring = Parent1.astype(bool).copy()
    for i in range(Offspring.shape[0]):
        diff = np.flatnonzero(Parent1[i] != Parent2[i])
        if diff.size == 0:                           # rand(1,0): no draw, no change
            continue
        o = Offspring[i, diff]
        MOne = o.mean()
        r = min(min(0.5, 2 * MOne), 2 * (1 - MOne))
        rate = np.zeros(diff.size)
        with np.errstate(divide="ignore", invalid="ignore"):
            if o.any():
                rate[o] = r / 2 / MOne
            if (~o).any():
                rate[~o] = r / 2 / (1 - MOne)
        exchange = rng.random(diff.size) < rate
        Offspring[i, diff[exchange]] = ~Offspring[i, diff[exchange]]
    return Offspring


def binary_mutation(Offspring, rng):
    """BinaryMutation.m (unbalanced bit-flip mutation)."""
    Offspring = np.array(Offspring, dtype=bool, copy=True)
    N, D = Offspring.shape
    MOne = Offspring.mean(axis=1) if D > 0 else np.full(N, np.nan)
    with np.errstate(divide="ignore", invalid="ignore"):
        # min(min(1/D,2*MOne),2*(1-MOne)) with MATLAB's NaN-ignoring min
        r = np.fmin(np.fmin(1.0 / D if D > 0 else np.inf, 2 * MOne), 2 * (1 - MOne))
        rate1 = np.tile((r / 2 / MOne)[:, None], (1, D))
        rate0 = np.tile((r / 2 / (1 - MOne))[:, None], (1, D))
    rate = np.where(Offspring, rate1, rate0)
    exchange = rng.random((N, D)) < rate
    Offspring[exchange] = ~Offspring[exchange]
    return Offspring


# ----------------------------------------------------------------------------- POSMining.m
def _cal_obj(Decs, T, Lens, Maximize):
    """CalObj of POSMining.m (vectorized; same arithmetic order)."""
    Decs = np.asarray(Decs, dtype=bool)
    T = np.asarray(T, dtype=bool)
    nT = T.shape[0]
    Objs = np.zeros((Decs.shape[0], 2))
    Len = Decs.sum(axis=1).astype(float)
    Ti = T.astype(np.int64)
    if Maximize:   # Tx(j): T(j,:) is a subset of Decs(i,:)
        TX = (Ti @ (~Decs).astype(np.int64).T) == 0          # (nT, nDecs)
    else:          # Tx(j): all(T(j,Decs(i,:)))  <=> Decs(i,:) subset of T(j,:)
        TX = ((~T).astype(np.int64) @ Decs.astype(np.int64).T) == 0
    with np.errstate(divide="ignore", invalid="ignore"):
        for i in range(Decs.shape[0]):
            Tx = TX[:, i]
            if not Tx.any():
                Objs[i, :] = 1
            else:
                Objs[i, 0] = 1 - Tx.sum() / nT
                if Maximize:
                    Objs[i, 1] = 1 - (Lens[Tx].sum() / Tx.sum()) / Len[i]
                else:
                    ratios = Len[i] / Lens[Tx]
                    Objs[i, 1] = 1 - np.cumsum(ratios)[-1] / ratios.size
    return Objs


def _env_sel_mining(PopDec, PopObj, N):
    """EnvironmentalSelection.m, nargin == 3 branch (pattern mining)."""
    _, ia, _ = unique_rows(PopDec.astype(float))
    uni = np.sort(ia)                                # unique(...,'rows','stable')
    PopDec = PopDec[uni]
    PopObj = PopObj[uni]
    FrontNo, MaxFNo = _ndsort(PopObj, N)
    Next = FrontNo <= MaxFNo
    Last = np.flatnonzero(FrontNo == MaxFNo)
    Del = _truncation(PopDec[Last].astype(float), int(Next.sum()) - N)
    Next[Last[Del]] = False
    return PopDec[Next], PopObj[Next], FrontNo[Next]


def _mining(Mask, PopDec, N, Maximize, rng):
    nF, d = Mask.shape
    Dec = np.zeros((N, d), bool)
    for i in range(N):
        k = math.ceil(rng.random() ** 2 * nF)
        sel = randperm(nF, k, rng=rng)
        Dec[i] = Mask[sel].any(axis=0) if Maximize else Mask[sel].all(axis=0)
    eye = np.eye(d, dtype=bool)
    PopDec = np.vstack([PopDec, Dec, ~eye if Maximize else eye, Mask])
    Lens = Mask.sum(axis=1).astype(float)
    PopObj = _cal_obj(PopDec, Mask, Lens, Maximize)
    PopDec, PopObj, FrontNo = _env_sel_mining(PopDec, PopObj, N)
    for _gen in range(10):
        MatingPool = TournamentSelection(2, 2 * N, FrontNo, rng=rng)
        OffDec = binary_crossover(PopDec[MatingPool[0::2]], PopDec[MatingPool[1::2]], rng)
        OffDec = binary_mutation(OffDec, rng)
        OffObj = _cal_obj(OffDec, Mask, Lens, Maximize)
        PopDec, PopObj, FrontNo = _env_sel_mining(np.vstack([PopDec, OffDec]), np.vstack([PopObj, OffObj]), N)
    return PopDec


def pos_mining(Mask, MaxP, MinP, N, rng):
    """[newMaxP,newMinP,Nonzero] = POSMining(Mask,MaxP,MinP,N); Nonzero returned 0-based."""
    D = Mask.shape[1]
    Nonzero = Mask.any(axis=0)
    maxp = _mining(Mask[:, Nonzero], MaxP[:, Nonzero], N, True, rng)
    newMaxP = np.zeros((maxp.shape[0], D), bool)
    newMaxP[:, Nonzero] = maxp
    k = min(newMaxP.shape[0], MaxP.shape[0])
    newMaxP[:k][:, ~Nonzero] = MaxP[:k][:, ~Nonzero]
    minp = _mining(Mask[:, Nonzero], MinP[:, Nonzero], N, False, rng)
    newMinP = np.zeros((minp.shape[0], D), bool)
    newMinP[:, Nonzero] = minp
    k = min(newMinP.shape[0], MinP.shape[0])
    newMinP[:k][:, ~Nonzero] = MinP[:k][:, ~Nonzero]
    return newMaxP, newMinP, np.flatnonzero(Nonzero)


# ----------------------------------------------------------------------------- Operator.m
def _ismember_rows(A, B):
    if A.shape[0] == 0 or B.shape[0] == 0:
        return np.zeros(A.shape[0], bool)
    out = np.zeros(A.shape[0], bool)
    for i in range(A.shape[0]):
        out[i] = np.any(np.all(B == A[i], axis=1))
    return out


def operator(task, ParentDec, ParentMask, MaxP, MinP, Nonzero, PopDec, rng):
    N, D = ParentMask.shape
    h = N // 2
    Parent1Mask = ParentMask[:h]
    Parent2Mask = ParentMask[h:]

    # Delete illegal subspaces
    exist = np.zeros((MaxP.shape[0], MinP.shape[0]), bool)
    for i in range(MinP.shape[0]):
        exist[:, i] = MaxP[:, MinP[i]].all(axis=1)
    MaxP = MaxP[exist.any(axis=1)]
    MinP = MinP[exist.any(axis=0)]

    # Binary variation
    OffMask = np.zeros((h, D), bool)
    if MaxP.shape[0] > 0 and MinP.shape[0] > 0:
        for i in range(h):
            maxp = MaxP[rng.integers(MaxP.shape[0])].copy()
            minp = MinP[rng.integers(MinP.shape[0])]
            maxp = maxp & ~minp
            cols = Nonzero[maxp]
            OffMask[i, cols] = binary_crossover(Parent1Mask[i, cols], Parent2Mask[i, cols], rng)[0]
            OffMask[i, Nonzero[minp]] = True
    else:
        OffMask = binary_crossover(Parent1Mask, Parent2Mask, rng)
    OffMask = binary_mutation(OffMask, rng)

    # Real variation
    enc = task.encoding
    if np.any(enc != 4):
        OffDec = OperatorGAhalf(task, ParentDec, rng=rng)
        OffDec[:, enc == 4] = 1
    else:
        OffDec = np.ones(OffMask.shape)

    # Remove duplicated solutions
    _, uni, _ = unique_rows(OffDec * OffMask)        # sorted order, first occurrences
    OffDec = OffDec[uni]
    OffMask = OffMask[uni]
    keep = ~_ismember_rows(OffDec * OffMask, PopDec)
    return OffDec[keep], OffMask[keep]


# ----------------------------------------------------------------------------- EnvironmentalSelection.m (nargin == 4)
def environmental_selection(pop: Pop, Dec, Mask, N):
    PopObj = pop.objs
    FrontNo, MaxFNo = NDSort(PopObj, pop.cons, N)
    Next = FrontNo <= MaxFNo
    Last = np.flatnonzero(FrontNo == MaxFNo)
    Del = _truncation(PopObj[Last], int(Next.sum()) - N)
    Next[Last[Del]] = False
    return pop[Next], Dec[Next], Mask[Next], FrontNo[Next]


# ----------------------------------------------------------------------------- PMMOEA.m
def run(task, **params):
    rng = task.rng
    N, D = task.N, task.D
    enc = task.encoding
    # Population initialization
    Dec = unifrnd(np.tile(task.lower, (N, 1)), np.tile(task.upper, (N, 1)), rng=rng)
    Dec[:, enc == 4] = 1
    Mask = np.zeros(Dec.shape, bool)
    for i in range(N):
        k = math.ceil(rng.random() ** 2 * D)
        Mask[i, randperm(D, k, rng=rng)] = True
    pop = task.evaluate(Dec * Mask)
    pop, Dec, Mask, FrontNo = environmental_selection(pop, Dec, Mask, N)

    # Optimization
    MaxP = np.zeros((20, D), bool)
    MinP = MaxP.copy()
    while task.not_terminated(pop):
        MaxP, MinP, Nonzero = pos_mining(pop.decs[FrontNo == 1] != 0, MaxP, MinP, 20, rng)
        MatingPool = TournamentSelection(2, N, FrontNo, rng=rng)
        OffDec, OffMask = operator(task, Dec[MatingPool], Mask[MatingPool], MaxP[:, Nonzero],
                                   MinP[:, Nonzero], Nonzero, pop.decs, rng)
        if OffDec.shape[0] > 0:
            off = task.evaluate(OffDec * OffMask)
            pop, Dec, Mask, FrontNo = environmental_selection(
                Pop.cat(pop, off), np.vstack([Dec, OffDec]), np.vstack([Mask, OffMask]), N)
    return task.result()
