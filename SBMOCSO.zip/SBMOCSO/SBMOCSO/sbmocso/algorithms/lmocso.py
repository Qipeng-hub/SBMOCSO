"""LMOCSO (Tian et al., 2020), following the PlatEMO implementation.

Implementation notes:
* Velocities are stored in Pop.adds; the initial population receives zero velocities.
* The argument of acos in the angle computation is clipped to [-1, 1].
* `_mmin` returns the index of the minimum while ignoring NaN.
"""
from __future__ import annotations

import numpy as np

from ..core import Pop
from ..operators import NDSort, UniformPoint, pdist2

NAME = "LMOCSO"
YEAR = 2020
REFERENCE = ("Y. Tian, X. Zheng, X. Zhang, and Y. Jin. Efficient large-scale multi-objective optimization "
             "based on a competitive swarm optimizer. IEEE Transactions on Cybernetics, 2020, 50(8): 3696-3708.")
CODING = "real"
DEFAULTS: dict = {}


def _mmin(A, axis=1):
    """[~, I] = min(A, [], axis) with MATLAB NaN semantics (NaN ignored; all-NaN -> first index)."""
    A = np.asarray(A, dtype=float)
    B = np.where(np.isnan(A), np.inf, A)
    I = np.argmin(B, axis=axis)
    return I


def _acos(c):
    return np.arccos(np.clip(c, -1.0, 1.0))


def environmental_selection(pop: Pop, V, theta):
    FrontNo, _ = NDSort(pop.objs, 1)
    pop = pop[FrontNo == 1]
    PopObj = pop.objs
    N, M = PopObj.shape
    NV = V.shape[0]

    # Translate the population
    PopObj = PopObj - PopObj.min(axis=0)[None, :]

    # Degree of violation
    CV = np.sum(np.maximum(0.0, pop.cons), axis=1)

    # Smallest angle between each reference vector and the others
    cosine = 1 - pdist2(V, V, "cosine")
    np.fill_diagonal(cosine, 0)
    gamma = np.min(_acos(cosine), axis=1)

    # Associate each solution with a reference vector
    with np.errstate(invalid="ignore", divide="ignore"):
        Angle = _acos(1 - pdist2(PopObj, V, "cosine"))
    associate = _mmin(Angle, axis=1)

    # One solution per reference vector
    Next = np.full(NV, -1, dtype=int)
    for i in np.unique(associate):
        current1 = np.flatnonzero((associate == i) & (CV == 0))
        current2 = np.flatnonzero((associate == i) & (CV != 0))
        if current1.size:
            APD = (1 + M * theta * Angle[current1, i] / gamma[i]) * np.sqrt(np.sum(PopObj[current1] ** 2, axis=1))
            best = int(_mmin(APD[None, :], axis=1)[0])
            Next[i] = current1[best]
        elif current2.size:
            best = int(np.argmin(CV[current2]))
            Next[i] = current2[best]
    return pop[Next[Next >= 0]]


def cal_fitness(PopObj):
    """Shift-based density: Fitness_i = min_j ||max(P_j, P_i) - P_i|| (larger = better)."""
    N = PopObj.shape[0]
    fmax = PopObj.max(axis=0)
    fmin = PopObj.min(axis=0)
    with np.errstate(invalid="ignore", divide="ignore"):
        P = (PopObj - fmin) / (fmax - fmin)
    # Dis(i,j) = norm(P_i - max(P_j, P_i)) for j ~= i, inf on the diagonal
    S = np.maximum(P[None, :, :], P[:, None, :])          # S[i, j] = max(P_j, P_i)
    Dis = np.sqrt(np.sum((P[:, None, :] - S) ** 2, axis=2))
    np.fill_diagonal(Dis, np.inf)
    Dis = np.where(np.isnan(Dis), np.inf, Dis)            # MATLAB min ignores NaN (diag is inf)
    return Dis.min(axis=1) if N else np.zeros(0)


def operator(task, Loser: Pop, Winner: Pop, rng):
    LoserDec = Loser.decs
    WinnerDec = Winner.decs
    N, D = LoserDec.shape
    LoserVel = Loser.adds if Loser.adds is not None else np.zeros((N, D))
    WinnerVel = Winner.adds if Winner.adds is not None else np.zeros((N, D))

    # Competitive swarm optimizer
    r1 = np.repeat(rng.random((N, 1)), D, axis=1)
    r2 = np.repeat(rng.random((N, 1)), D, axis=1)
    OffVel = r1 * LoserVel + r2 * (WinnerDec - LoserDec)
    OffDec = LoserDec + OffVel + r1 * (OffVel - LoserVel)

    # Add the winners
    OffDec = np.vstack([OffDec, WinnerDec])
    OffVel = np.vstack([OffVel, WinnerVel])

    # Polynomial mutation
    Lower = np.tile(task.lower, (2 * N, 1))
    Upper = np.tile(task.upper, (2 * N, 1))
    disM = 20
    Site = rng.random((2 * N, D)) < 1 / D
    mu = rng.random((2 * N, D))
    temp = Site & (mu <= 0.5)
    OffDec = np.maximum(np.minimum(OffDec, Upper), Lower)
    L, U, m, o = Lower[temp], Upper[temp], mu[temp], OffDec[temp]
    OffDec[temp] = o + (U - L) * ((2 * m + (1 - 2 * m) * (1 - (o - L) / (U - L)) ** (disM + 1)) ** (1 / (disM + 1)) - 1)
    temp = Site & (mu > 0.5)
    L, U, m, o = Lower[temp], Upper[temp], mu[temp], OffDec[temp]
    OffDec[temp] = o + (U - L) * (1 - (2 * (1 - m) + 2 * (m - 0.5) * (1 - (U - o) / (U - L)) ** (disM + 1)) ** (1 / (disM + 1)))
    return task.evaluate(OffDec, OffVel)


def run(task, **params):
    rng = task.rng
    V, task.N = UniformPoint(task.N, task.M)
    pop = task.initialization()
    pop = pop.with_adds(np.zeros((len(pop), task.D)))     # zero initial velocities
    pop = environmental_selection(pop, V, (task.FE / task.max_fes) ** 2)

    while task.not_terminated(pop):
        Fitness = cal_fitness(pop.objs)
        n = len(pop)
        if n >= 2:
            Rank = rng.permutation(n)[: (n // 2) * 2]
        else:
            Rank = np.array([0, 0])
        h = len(Rank) // 2
        Loser = Rank[:h].copy()
        Winner = Rank[h:].copy()
        Change = Fitness[Loser] >= Fitness[Winner]
        Temp = Winner[Change].copy()
        Winner[Change] = Loser[Change]
        Loser[Change] = Temp
        Offspring = operator(task, pop[Loser], pop[Winner], rng)
        pop = environmental_selection(Pop.cat(pop, Offspring), V, (task.FE / task.max_fes) ** 2)
    return task.result()
