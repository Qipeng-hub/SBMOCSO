"""AFSEA (Zhang et al., 2025), following the PlatEMO implementation.

Every decision variable is scored by non-dominated sorting of the D single-variable solutions together
with an all-zero solution, and a greedy pass (NDS-FS) grows a subsequence of variables that is used to
build the initial masks. In every generation, Relief weights computed with the first front as the
positive class guide binary crossover and mutation; when all weights are zero, the SparseEA operator is
used instead. Survival removes duplicated objective vectors and truncates the last front as in SPEA2.
All initial evaluations count toward the budget.

Implementation notes:
* As in the PlatEMO code, the SparseEA operator indexes the score vector (entry 0 belongs to the all-zero
  solution) with the 0-based feature index, and the Relief-guided mutation compares mask values with
  min(Delta, 1) to choose its candidates.
* Where the PlatEMO code stops with an error (no variable passes the first NDS-FS test, or Relief finds
  no nearest miss), a RuntimeError is raised.
"""
from __future__ import annotations

import math

import numpy as np

from ..core import Pop
from ..operators import (CrowdingDistance, NDSort, OperatorGAhalf, TournamentSelection, pdist2, unifrnd,
                         unique_rows)

NAME = "AFSEA"
YEAR = 2025
REFERENCE = ("P. Zhang, H. Yin, Y. Tian, and X. Zhang. An adjoint feature-selection-based evolutionary "
             "algorithm for sparse large-scale multiobjective optimization. Complex & Intelligent Systems, "
             "2025, 11: 127.")
CODING = "binary"
DEFAULTS: dict = {}


# ----------------------------------------------------------------------------- EnvironmentalSelection.m


def _lex_first_min_row(T):
    """Index of Rank(1) from [~,Rank] = sortrows(T): first row (stable) among the lexicographically
    smallest ones; NaN compares as larger than any number (MATLAB sorts NaN last)."""
    cand = np.arange(T.shape[0])
    for c in range(T.shape[1]):
        if len(cand) == 1:
            break
        v = T[cand, c]
        nan = np.isnan(v)
        if nan.all():
            continue                               # all NaN in this column: still tied
        m = np.min(v[~nan])
        cand = cand[v == m]
    return int(cand[0])


def _truncation(PopObj, K):
    Distance = pdist2(PopObj, PopObj)
    np.fill_diagonal(Distance, np.inf)
    n = PopObj.shape[0]
    Del = np.zeros(n, bool)
    while Del.sum() < K:
        Remain = np.flatnonzero(~Del)
        Temp = np.sort(Distance[np.ix_(Remain, Remain)], axis=1)   # numpy sorts NaN last, as MATLAB
        Del[Remain[_lex_first_min_row(Temp)]] = True
    return Del


def environmental_selection(pop: Pop, Dec, Mask, N):
    # Delete duplicated solutions
    _, uni, _ = unique_rows(pop.objs)
    pop, Dec, Mask = pop[uni], Dec[uni], Mask[uni]
    N = min(N, len(pop))
    # Calculate the fitness of each solution
    FrontNo, MaxFNo = NDSort(pop.objs, N)
    Next = FrontNo < MaxFNo
    PopObj = pop.objs
    f1 = FrontNo == 1
    fmax = np.max(PopObj[f1], axis=0)
    fmin = np.min(PopObj[f1], axis=0)
    with np.errstate(divide="ignore", invalid="ignore"):
        PopObj = (PopObj - fmin) / (fmax - fmin)
    # Environmental selection
    Last = np.flatnonzero(FrontNo == MaxFNo)
    with np.errstate(invalid="ignore"):
        dele = _truncation(PopObj[Last], len(Last) - N + int(Next.sum()))
    Next[Last[~dele]] = True
    pop, Dec, Mask, FrontNo = pop[Next], Dec[Next], Mask[Next], FrontNo[Next]
    CrowdDis = CrowdingDistance(pop.objs, FrontNo)
    return pop, Dec, Mask, FrontNo, CrowdDis


# ----------------------------------------------------------------------------- Relief.m


def _relief(task, pop: Pop, FrontNo):
    n = len(pop)
    labels = np.zeros(task.N)                      # zeros(1,Problem.N); n <= N after selection
    labels[:n][FrontNo == 1] = 1                   # labels(FrontNo == 1) = 1
    features = pop.decs
    distance = pdist2(features, features)
    np.fill_diagonal(distance, np.inf)             # + diag(inf+zeros(1,n))
    with np.errstate(divide="ignore", invalid="ignore"):
        data = (features - task.lower) / (task.upper - task.lower)
    if np.all(labels == 1):
        return np.zeros(task.D)
    lab = labels[:n]
    delta = np.zeros((n, task.D))
    for i in range(n):
        same = lab == lab[i]
        hit = np.flatnonzero(same)
        miss = np.flatnonzero(~same)
        if miss.size == 0:
            raise RuntimeError("AFSEA Relief: no near-miss candidate (all solutions in the first front but "
                               "fewer than N solutions); PlatEMO raises a size-mismatch error here")
        nearhit = hit[np.argmin(distance[hit, i])]       # min(): first minimum
        nearmiss = miss[np.argmin(distance[miss, i])]
        diff_hit = np.abs(data[nearhit] - data[i])
        diff_miss = np.abs(data[nearmiss] - data[i])
        delta[i] = diff_miss ** 2 - diff_hit ** 2
    if n == 1:                                     # sum of a 1xD row is a scalar in MATLAB
        return np.full(task.D, delta.sum())
    return delta.sum(axis=0)


# ----------------------------------------------------------------------------- Operator.m / OperatorDelta.m


def _ts(values, rng):
    """TS(x): binary tournament on one candidate set (smaller wins); [] for an empty set."""
    if len(values) == 0:
        return None
    return TournamentSelection(2, 1, values, rng=rng)[0]


def _offspring_dec(task, ParentDec, n_half):
    if np.any(task.encoding != 4):
        OffDec = OperatorGAhalf(task, ParentDec)
        OffDec[:, task.encoding == 4] = 1
    else:
        OffDec = np.ones((n_half, task.D))
    return OffDec


def _operator(task, ParentDec, ParentMask, Fitness):
    """Operator.m (SparseEA operator). Fitness is the full (D+1) score vector, indexed by the 0-based
    feature index, as in the PlatEMO code (see the module docstring)."""
    rng = task.rng
    N = ParentDec.shape[0]
    h = N // 2
    P1, P2 = ParentMask[:h], ParentMask[h:]
    OffMask = P1.copy()
    for i in range(h):
        if rng.random() < 0.5:
            index = np.flatnonzero((P1[i] != 0) & ~(P2[i] != 0))
            k = _ts(-Fitness[index], rng)
            if k is not None:
                OffMask[i, index[k]] = 0
        else:
            index = np.flatnonzero(~(P1[i] != 0) & (P2[i] != 0))
            k = _ts(Fitness[index], rng)
            if k is not None:
                OffMask[i, index[k]] = P2[i, index[k]]
    for i in range(h):
        if rng.random() < 0.5:
            index = np.flatnonzero(OffMask[i] != 0)
            k = _ts(-Fitness[index], rng)
            if k is not None:
                OffMask[i, index[k]] = 0
        else:
            index = np.flatnonzero(OffMask[i] == 0)
            k = _ts(Fitness[index], rng)
            if k is not None:
                OffMask[i, index[k]] = 1
    OffDec = _offspring_dec(task, ParentDec, h)
    return OffDec, OffMask


def _operator_delta(task, ParentMask, ParentDec, Delta):
    rng = task.rng
    N = ParentMask.shape[0]
    h = N // 2
    P1, P2 = ParentMask[:h], ParentMask[h:]
    OffMask = P1.copy()
    for i in range(h):
        if rng.random() < 0.5:
            index = np.flatnonzero((P1[i] != 0) & ~(P2[i] != 0))
            k = _ts(Delta[index], rng)
            if k is not None:
                OffMask[i, index[k]] = 0
        else:
            index = np.flatnonzero(~(P1[i] != 0) & (P2[i] != 0))
            k = _ts(-Delta[index], rng)
            if k is not None:
                OffMask[i, index[k]] = P2[i, index[k]]
    Delta = Delta.copy()
    Delta[Delta > 1] = 1
    for i in range(h):
        index = np.flatnonzero(OffMask[i] != Delta)   # mask values compared with the weights, as in PlatEMO
        if rng.random() < 0.5:
            k = _ts(-Delta[index], rng)
            if k is not None:
                OffMask[i, index[k]] = 1
        else:
            k = _ts(Delta[index], rng)
            if k is not None:
                OffMask[i, index[k]] = 0
    OffDec = _offspring_dec(task, ParentDec, h)
    return OffMask, OffDec


# ----------------------------------------------------------------------------- AFSEA.m


def _nds_fs(Fitness):
    """Greedy NDS-FS subsequence; returns 0-based feature indices (bestSequence - 1)."""
    Standard_0 = Fitness[0]
    bestindex = int(np.argmin(Fitness[1:]))
    bestScore = Fitness[1:][bestindex]
    L = 1
    nz = np.flatnonzero(Fitness)                   # find(Fitness), 0-based Fitness positions
    SequenceSet = [[int(k)] for k in nz[nz != 0]]  # num2cell(setdiff(find(Fitness),1))
    bestSequence = None
    while bestScore is not None and bestScore <= Standard_0 * L:
        bestSequence = SequenceSet[bestindex]
        excl = np.zeros(len(Fitness), bool)
        excl[0] = True
        excl[bestSequence] = True
        rest = nz[~excl[nz]]                       # setdiff(find(Fitness),[1,bestSequence]) (sorted)
        base = float(np.sum(Fitness[bestSequence]))
        Score = base + Fitness[rest]
        SequenceSet = _LazySeq(bestSequence, rest)
        if len(rest) == 0:
            bestScore = None                       # min([]) = [] -> while condition false
        else:
            bestindex = int(np.argmin(Score))
            bestScore = Score[bestindex]
        L += 1
    if bestSequence is None:
        raise RuntimeError("AFSEA NDS-FS: no variable passed the first test; PlatEMO errors "
                           "(bestSequence undefined)")
    return np.asarray(bestSequence, dtype=int) - 1


class _LazySeq:
    """SequenceSet{i} = [bestSequence, rest(i)] without materialising every list."""

    def __init__(self, prefix, rest):
        self.prefix, self.rest = list(prefix), rest

    def __getitem__(self, i):
        return self.prefix + [int(self.rest[i])]


def run(task, **params):
    rng = task.rng
    D, N = task.D, task.N
    enc = task.encoding
    # Population initialization: fitness of each decision variable
    TDec, TMask, TempPop = [], [], []
    Fitness = np.zeros(D + 1)
    for _ in range(1 + 4 * int(np.any(enc != 4))):
        standard_Mask = np.zeros(D)
        standard_Dec = rng.random(D)               # drawn (and unused) as in PlatEMO
        standard = standard_Mask * standard_Dec
        Dec = unifrnd(np.tile(task.lower, (D, 1)), np.tile(task.upper, (D, 1)), rng=rng)
        Dec[:, enc == 4] = 1
        Mask = np.eye(D)
        TPopulation = task.evaluate(np.vstack([standard, Dec * Mask]))
        TDec.append(Dec)
        TMask.append(Mask)
        TempPop.append(TPopulation[np.arange(1, D + 1)])
        Fitness = Fitness + NDSort(np.hstack([TPopulation.objs, TPopulation.cons]), np.inf)[0]
    TDec, TMask, TempPop = np.vstack(TDec), np.vstack(TMask), Pop.cat(*TempPop)
    # Pick the best subsequence based on NDS-FS
    bestSequence = _nds_fs(Fitness)
    Mask = np.zeros((N, D))
    for i in range(N):
        if rng.random() < 0.5:
            Mask[i, bestSequence] = 1
        else:
            Mask[i, TournamentSelection(2, math.ceil(rng.random() * D), Fitness[1:], rng=rng)] = 1
    # Generate initial population
    Dec = unifrnd(np.tile(task.lower, (N, 1)), np.tile(task.upper, (N, 1)), rng=rng)
    Dec[:, enc == 4] = 1
    Population = task.evaluate(Dec * Mask)
    Population, Dec, Mask, FrontNo, CrowdDis = environmental_selection(
        Pop.cat(Population, TempPop), np.vstack([Dec, TDec]), np.vstack([Mask, TMask]), N)
    Delta = np.zeros(D)
    # Optimization
    while task.not_terminated(Population):
        MatingPool = TournamentSelection(2, 2 * N, FrontNo, -CrowdDis, rng=rng)
        delta = _relief(task, Population, FrontNo)
        Delta = Delta + np.abs(delta)
        if np.all(delta == 0):
            OffDec, OffMask = _operator(task, Dec[MatingPool], Mask[MatingPool], Fitness)
        else:
            OffMask, OffDec = _operator_delta(task, Mask[MatingPool], Dec[MatingPool], Delta)
        Offspring = task.evaluate(OffDec * OffMask)
        Population, Dec, Mask, FrontNo, CrowdDis = environmental_selection(
            Pop.cat(Population, Offspring), np.vstack([Dec, OffDec]), np.vstack([Mask, OffMask]), N)
    return task.result()
