"""SparseEA2 (Zhang et al., 2023), following the PlatEMO implementation.

The main loop and the environmental selection are those of SparseEA. The operator applies SBX to Dec,
followed by a grouped polynomial mutation, and the mask mutation is restricted to one group of variables.
As in PlatEMO, the mask mutation is applied only when the problem has non-binary variables, so on binary
feature selection only the mask crossover is used.
"""
from __future__ import annotations

import numpy as np

from ..core import Pop
from ..operators import TournamentSelection, msort

from .sparseea import environmental_selection, initial_population, ts, variable_scores

NAME = "SparseEA2"
YEAR = 2023
REFERENCE = ("Y. Zhang, Y. Tian, and X. Zhang. Improved SparseEA for sparse large-scale multi-objective "
             "optimization problems. Complex & Intelligent Systems, 2023, 9: 1127-1142.")
CODING = "binary"
DEFAULTS: dict = {}

N_GROUPS = 4          # hard-coded in Operator.m ("4 -- numberofgroups")


def create_groups(numberOfGroups, xPrime, numberOfVariables):
    """CreateGroups (ordered grouping) of GLP_OperatorGAhalf.m; returns group labels 1..numberOfGroups."""
    n = xPrime.shape[0]
    out = np.ones((n, numberOfVariables))
    varsPerGroup = numberOfVariables // numberOfGroups
    for sol in range(n):
        _, I = msort(xPrime[sol])                       # [~,I] = sort(vars), stable
        lab = np.ones(numberOfVariables)
        for i in range(1, numberOfGroups):
            lab[I[(i - 1) * varsPerGroup:i * varsPerGroup]] = i
        lab[I[(numberOfGroups - 1) * varsPerGroup:]] = numberOfGroups
        out[sol] = lab
    return out


def glp_operator_ga_half(task, Parent1, Parent2, numberOfGroups):
    """GLP_OperatorGAhalf.m: SBX (one child per pair) + grouped polynomial mutation."""
    rng = task.rng
    proC, disC, disM = 1, 20, 20
    N, D = Parent1.shape
    # SBX, same random draws as GAreal
    beta = np.zeros((N, D))
    mu = rng.random((N, D))
    lo = mu <= 0.5
    beta[lo] = (2 * mu[lo]) ** (1 / (disC + 1))
    beta[~lo] = (2 - 2 * mu[~lo]) ** (-1 / (disC + 1))
    beta = beta * (-1.0) ** rng.integers(0, 2, size=(N, D))
    beta[rng.random((N, D)) < 0.5] = 1
    beta[np.repeat(rng.random((N, 1)) > proC, D, axis=1)] = 1
    Off = (Parent1 + Parent2) / 2 + beta * (Parent1 - Parent2) / 2
    Lower = np.tile(task.lower, (N, 1))
    Upper = np.tile(task.upper, (N, 1))
    # Groups on the (unclipped) SBX offspring, one random group per offspring
    outIndexList = create_groups(numberOfGroups, Off, D)
    chosengroups = rng.integers(1, numberOfGroups + 1, size=(N, 1)).astype(float)   # randi(G,N,1)
    Site = outIndexList == chosengroups
    mu = np.repeat(rng.random((N, 1)), D, axis=1)
    Off = np.minimum(np.maximum(Off, Lower), Upper)
    with np.errstate(divide="ignore", invalid="ignore"):
        t = Site & (mu <= 0.5)
        L, U, m, o = Lower[t], Upper[t], mu[t], Off[t]
        Off[t] = o + (U - L) * ((2.0 * m + (1 - 2.0 * m) * (1 - (o - L) / (U - L)) ** (disM + 1)) ** (1 / (disM + 1)) - 1)
        t = Site & (mu > 0.5)
        L, U, m, o = Lower[t], Upper[t], mu[t], Off[t]
        Off[t] = o + (U - L) * (1 - (2.0 * (1 - m) + 2.0 * (m - 0.5) * (1 - (U - o) / (U - L)) ** (disM + 1)) ** (1 / (disM + 1)))
    return Off, outIndexList, chosengroups


def operator(task, ParentDec, ParentMask, Fitness):
    """Operator.m of SparseEA2."""
    rng = task.rng
    N = ParentDec.shape[0]
    h = N // 2
    Parent1Dec, Parent2Dec = ParentDec[:h], ParentDec[h:2 * h]
    Parent1Mask, Parent2Mask = ParentMask[:h], ParentMask[h:2 * h]
    nonbinary = bool(np.any(task.encoding != 4))
    # Crossover and mutation for dec
    if nonbinary:
        OffDec, groupIndex, chosengroups = glp_operator_ga_half(task, Parent1Dec, Parent2Dec, N_GROUPS)
        OffDec[:, task.encoding == 4] = 1
    else:
        OffDec = np.ones(Parent1Dec.shape)
    # Crossover for mask (identical to SparseEA)
    OffMask = Parent1Mask.copy()
    for i in range(h):
        if rng.random() < 0.5:
            index = np.flatnonzero(Parent1Mask[i] & ~Parent2Mask[i])
            index = index[ts(-Fitness[index], rng)]
            OffMask[i, index] = False
        else:
            index = np.flatnonzero(~Parent1Mask[i] & Parent2Mask[i])
            index = index[ts(Fitness[index], rng)]
            OffMask[i, index] = Parent2Mask[i, index]
    # Mutation for mask, restricted to the chosen group (PlatEMO: only when a non-binary variable exists)
    if nonbinary:
        chosenindex = groupIndex == chosengroups
        for i in range(h):
            if rng.random() < 0.5:
                index = np.flatnonzero(OffMask[i] & chosenindex[i])
                index = index[ts(-Fitness[index], rng)]
                OffMask[i, index] = False
            else:
                index = np.flatnonzero(~OffMask[i] & chosenindex[i])
                index = index[ts(Fitness[index], rng)]
                OffMask[i, index] = True
    return OffDec, OffMask


def run(task, **params):
    # Population initialization (identical to SparseEA.m)
    TDec, TMask, TempPop, Fitness = variable_scores(task)
    Dec, Mask = initial_population(task, Fitness)
    pop = task.evaluate(Dec * Mask)
    pop, Dec, Mask, FrontNo, CrowdDis = environmental_selection(
        Pop.cat(pop, TempPop), np.vstack([Dec, TDec]), np.vstack([Mask, TMask]), task.N)
    # Optimization
    while task.not_terminated(pop):
        MatingPool = TournamentSelection(2, 2 * task.N, FrontNo, -CrowdDis, rng=task.rng)
        OffDec, OffMask = operator(task, Dec[MatingPool], Mask[MatingPool], Fitness)
        off = task.evaluate(OffDec * OffMask)
        pop, Dec, Mask, FrontNo, CrowdDis = environmental_selection(
            Pop.cat(pop, off), np.vstack([Dec, OffDec]), np.vstack([Mask, OffMask]), task.N)
    return task.result()
