"""Registry of the compared algorithms.

Every module provides NAME, CODING ("binary" or "real"), DEFAULTS and run(task, **params). A real-coded
algorithm selects a gene when its decision variable exceeds 0.5.
"""
import importlib

MODULES = {
    "NSGA-II": "nsga2",
    "SparseEA": "sparseea",
    "PM-MOEA": "pmmoea",
    "MSKEA": "mskea",
    "SparseEA2": "sparseea2",
    "AFSEA": "afsea",
    "LMOCSO": "lmocso",
    "S-ECSO": "secso",
    "SBMOCSO": "sbmocso",
}


def get(name):
    return importlib.import_module(f"{__name__}.{MODULES[name]}")


def defaults(name):
    return dict(get(name).DEFAULTS)
