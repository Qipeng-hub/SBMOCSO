"""SBMOCSO: sparse binary multi-objective competitive swarm optimizer.

One generation:
  * the swarm is divided into random pairs; in each pair the winner is the particle preferred by the
    crowded comparison of NSGA-II (front number, then crowding distance from the last environmental
    selection); winners pass on unchanged, and only the updated losers are evaluated;
  * competitive learning on the disagreement set: the loser takes the winner's value on
    k = ceil(r * |A u B|) randomly chosen positions in which the two masks differ, r ~ U(0, 1) per pair;
  * one-bit sparse mutation: add a random unselected gene or drop a random selected gene,
    probability 0.5 each;
  * environmental selection: swarm and new masks are merged, duplicated objective vectors are removed
    (first occurrence kept), and the next swarm is chosen by non-dominated sorting and crowding distance.
The initial panel sizes are log-uniform: each initial mask holds round(D ** u) random genes, u ~ U(0, 1).

Options used in the paper:
  init="uniform"  uniform initial panel size on {1, ..., D} (ablation)
  full_copy=True  the loser copies the winner on the whole disagreement set (ablation)
  mutate=False    no sparse mutation (ablation)
"""
from __future__ import annotations

import numpy as np

from ..core import Pop
from ..operators import CrowdingDistance, NDSort, msort

NAME = "SBMOCSO"
CODING = "binary"
DEFAULTS = dict(init="log", full_copy=False, mutate=True)


def environmental_selection(pop: Pop, N: int):
    _, uni = np.unique(pop.objs, axis=0, return_index=True)
    pop = pop[np.sort(uni)]
    N = min(N, len(pop))
    FrontNo, MaxFNo = NDSort(pop.objs, pop.cons, N)
    Next = FrontNo < MaxFNo
    CrowdDis = CrowdingDistance(pop.objs, FrontNo)
    Last = np.where(FrontNo == MaxFNo)[0]
    _, Rank = msort(CrowdDis[Last], True)
    Next[Last[Rank[:N - int(Next.sum())]]] = True
    return pop[Next], FrontNo[Next], CrowdDis[Next]


def _better(i, j, FrontNo, CrowdDis):
    """Crowded comparison: lower front number first, then larger crowding distance."""
    if FrontNo[i] != FrontNo[j]:
        return FrontNo[i] < FrontNo[j]
    return CrowdDis[i] >= CrowdDis[j]


def _pick(cands, weights, k, rng):
    """k distinct elements of cands, sampled without replacement with probabilities proportional to weights."""
    if k >= len(cands):
        return cands
    w = np.asarray(weights, float) + 1e-12
    return rng.choice(cands, size=k, replace=False, p=w / w.sum())


def run(task, init="log", full_copy=False, mutate=True):
    rng, D, N = task.rng, task.D, task.N

    # initialization
    dec = np.zeros((N, D))
    for i in range(N):
        if init == "log":
            k = int(np.clip(np.round(D ** rng.random()), 1, D))
        else:
            k = rng.integers(1, D + 1)
        dec[i, rng.choice(D, size=k, replace=False)] = 1
    pop = task.evaluate(dec)
    pop, FrontNo, CrowdDis = environmental_selection(pop, N)

    while task.not_terminated(pop):
        n = len(pop)
        perm = rng.permutation(n)[: (n // 2) * 2]
        A, B = perm[: len(perm) // 2], perm[len(perm) // 2:]
        new = []
        for a, b in zip(A, B):
            w, l = (a, b) if _better(a, b, FrontNo, CrowdDis) else (b, a)
            xw, xl = pop.decs[w] > 0.5, pop.decs[l] > 0.5
            add = np.where(xw & ~xl)[0]
            drop = np.where(xl & ~xw)[0]

            # competitive learning on the disagreement set
            x = xl.copy()
            nd = len(add) + len(drop)
            if nd:
                r = 1.0 if full_copy else rng.random()
                k = int(np.ceil(r * nd))
                diff = np.concatenate([add, drop])
                sel = _pick(diff, np.ones(nd), k, rng)
                x[sel] = xw[sel]

            # one-bit sparse mutation; the first of two drawn candidates is used, which keeps the
            # random number stream of the runs reported in the paper
            if mutate:
                on, off = np.where(x)[0], np.where(~x)[0]
                if rng.random() < 0.5 and len(off):
                    c = rng.choice(off, size=min(2, len(off)), replace=False)
                    x[c[0]] = True
                elif len(on) > 1:
                    c = rng.choice(on, size=min(2, len(on)), replace=False)
                    x[c[0]] = False
            new.append(x.astype(float))

        off = task.evaluate(np.array(new))
        pop, FrontNo, CrowdDis = environmental_selection(Pop.cat(pop, off), N)
    return task.result()
