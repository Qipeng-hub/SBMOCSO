"""Utility functions shared by the algorithms.

Python implementations of the PlatEMO utility functions used here (non-dominated sorting, crowding
distance, tournament selection, reference points and genetic operators), together with small helpers
that reproduce MATLAB sorting and tie-breaking rules. Returned indices are 0-based, and front numbers
are 1, 2, ... (np.inf for unsorted solutions). Random operators take a numpy Generator `rng`; if it
is None, `Problem.rng` is used. Operators that receive a Pop return an evaluated Pop.
"""
from __future__ import annotations

import math
from itertools import combinations

import numpy as np

from .core import Pop


def rowsum(A) -> np.ndarray:
    """sum(A,2) with MATLAB's sequential summation order (numpy uses pairwise sums)."""
    A = np.asarray(A, dtype=float)
    if A.ndim == 1:
        A = A[None, :]
    if A.shape[1] == 0:
        return np.zeros(A.shape[0])
    return np.cumsum(A, axis=1)[:, -1]


def msort(x, descend: bool = False):
    """[s, idx] = sort(x) / sort(x,'descend') for a vector: stable; NaN last (ascend) or first
    (descend) as in MATLAB. Returns (sorted values, 0-based indices)."""
    x = np.asarray(x, dtype=float).ravel()
    if not descend:
        idx = np.argsort(x, kind="stable")          # numpy also puts NaN last
    else:
        nan = np.isnan(x)
        nn = np.flatnonzero(~nan)
        idx = np.concatenate([np.flatnonzero(nan), nn[np.argsort(-x[nn], kind="stable")]])
    return x[idx], idx


def sortrows(A, cols=None):
    """[B, idx] = sortrows(A) (lexicographic, stable). cols: 1-based column list, negative = descend."""
    A = np.asarray(A, dtype=float)
    if A.ndim == 1:
        A = A[:, None]
    if cols is None:
        cols = list(range(1, A.shape[1] + 1))
    idx = np.arange(A.shape[0])
    for c in reversed(list(cols)):                 # stable sorts from the last key to the first
        _, o = msort(A[idx, abs(c) - 1], descend=c < 0)
        idx = idx[o]
    return A[idx], idx


def unique_rows(A):
    """[C, ia, ic] = unique(A,'rows') with MATLAB semantics: C sorted lexicographically, ia = first
    occurrence (0-based), ic (0-based) such that C[ic] == A."""
    A = np.asarray(A, dtype=float)
    if A.ndim == 1:
        A = A[:, None]
    n = A.shape[0]
    if n == 0:
        return A.copy(), np.zeros(0, int), np.zeros(0, int)
    _, order = sortrows(A)
    S = A[order]
    new = np.ones(n, bool)
    new[1:] = np.any(S[1:] != S[:-1], axis=1)
    grp = np.cumsum(new) - 1
    ic = np.empty(n, int)
    ic[order] = grp
    ia = order[new]                                # stable sort -> first occurrence of each group
    return S[new], ia, ic


def pdist2(A, B, metric: str = "euclidean"):
    """MATLAB pdist2 for the metrics PlatEMO uses: euclidean, squaredeuclidean, cosine (1 - cos),
    cityblock, chebychev, minkowski (p=2)."""
    from scipy.spatial.distance import cdist
    A = np.atleast_2d(np.asarray(A, dtype=float))
    B = np.atleast_2d(np.asarray(B, dtype=float))
    m = metric.lower()
    if m == "euclidean":
        return cdist(A, B, "euclidean")
    if m == "squaredeuclidean":
        return cdist(A, B, "sqeuclidean")
    if m == "cosine":
        with np.errstate(divide="ignore", invalid="ignore"):
            na = np.sqrt(np.sum(A ** 2, axis=1))[:, None]
            nb = np.sqrt(np.sum(B ** 2, axis=1))[None, :]
            return 1.0 - (A @ B.T) / (na * nb)
    if m == "cityblock":
        return cdist(A, B, "cityblock")
    if m in ("chebychev", "chebyshev"):
        return cdist(A, B, "chebyshev")
    if m == "minkowski":
        return cdist(A, B, "minkowski", p=2)
    raise ValueError(metric)


def unifrnd(lower, upper, size=None, rng=None):
    """unifrnd(a, b[, size]) = a + (b - a) .* rand."""
    lower = np.asarray(lower, dtype=float)
    upper = np.asarray(upper, dtype=float)
    shape = np.broadcast(lower, upper).shape if size is None else size
    return lower + (upper - lower) * rng.random(shape)


def randperm(n: int, k: int | None = None, rng=None) -> np.ndarray:
    """randperm(n[, k]) as 0-based indices."""
    p = rng.permutation(n)
    return p if k is None else p[:k]


def _rng_of(Problem, rng):
    if rng is not None:
        return rng
    r = getattr(Problem, "rng", None)
    if r is None:
        raise ValueError("pass rng= (Problem has no .rng)")
    return r


def _dominated_matrix(F):
    """dom[i, j] = True iff row j Pareto-dominates row i (minimization)."""
    le = np.all(F[None, :, :] <= F[:, None, :], axis=2)   # F_j <= F_i
    lt = np.any(F[None, :, :] < F[:, None, :], axis=2)
    return le & lt


def NDSort(PopObj, *args):
    """[FrontNo, MaxFNo] = NDSort(PopObj, nSort) or NDSort(PopObj, PopCon, nSort).

    Sorts fronts until at least min(nSort, N) solutions are assigned (whole fronts); the rest get
    np.inf. Constrained form: infeasible rows (any con > 0) are replaced by max(PopObj) + CV in every
    objective, exactly as PlatEMO does, then sorted by Pareto dominance (identical to ENS-SS/T-ENS).
    """
    PopObj = np.array(PopObj, dtype=float, copy=True)
    if PopObj.ndim == 1:
        PopObj = PopObj[:, None]
    N, M = PopObj.shape
    if len(args) == 1:
        nSort = args[0]
    elif len(args) == 2:
        PopCon, nSort = args
        PopCon = np.asarray(PopCon, dtype=float).reshape(N, -1)
        Infeasible = np.any(PopCon > 0, axis=1)
        if Infeasible.any():
            mx = np.fmax.reduce(PopObj, axis=0)           # max ignores NaN as in MATLAB
            cv = rowsum(np.maximum(0.0, PopCon[Infeasible]))
            PopObj[Infeasible] = mx[None, :] + cv[:, None]
    else:
        raise TypeError("NDSort(PopObj, nSort) or NDSort(PopObj, PopCon, nSort)")
    FrontNo = np.full(N, np.inf)
    if N == 0:
        return FrontNo, 0
    target = min(float(nSort), N)
    MaxFNo = 0
    if N <= 4000:
        dom = _dominated_matrix(PopObj)
        cnt = dom.sum(axis=1)
        remaining = np.ones(N, bool)
        nsorted = 0
        while nsorted < target:
            MaxFNo += 1
            front = remaining & (cnt == 0)
            FrontNo[front] = MaxFNo
            remaining &= ~front
            nsorted += int(front.sum())
            if remaining.any():
                cnt = cnt - dom[:, front].sum(axis=1)
    else:                                                  # memory-light peeling
        remaining = np.arange(N)
        nsorted = 0
        while nsorted < target:
            MaxFNo += 1
            R = PopObj[remaining]
            isdom = np.zeros(len(remaining), bool)
            for s in range(0, len(remaining), 512):
                isdom[s:s + 512] = _dominated_matrix_block(R[s:s + 512], R)
            front = remaining[~isdom]
            FrontNo[front] = MaxFNo
            remaining = remaining[isdom]
            nsorted += len(front)
    return FrontNo, MaxFNo


def _dominated_matrix_block(Fi, F):
    le = np.all(F[None, :, :] <= Fi[:, None, :], axis=2)
    lt = np.any(F[None, :, :] < Fi[:, None, :], axis=2)
    return np.any(le & lt, axis=1)


def CrowdingDistance(PopObj, FrontNo=None):
    """CrowdingDistance(PopObj[, FrontNo]) front by front; boundary solutions get inf; a constant
    objective inside a front gives NaN (0/0) exactly as in PlatEMO."""
    PopObj = np.asarray(PopObj, dtype=float)
    N, M = PopObj.shape
    FrontNo = np.ones(N) if FrontNo is None else np.asarray(FrontNo, dtype=float).ravel()
    CrowdDis = np.zeros(N)
    fronts = np.unique(FrontNo)
    fronts = fronts[~np.isinf(fronts)]
    with np.errstate(divide="ignore", invalid="ignore"):
        for f in fronts:
            Front = np.flatnonzero(FrontNo == f)
            O = PopObj[Front]
            Fmax = np.fmax.reduce(O, axis=0)
            Fmin = np.fmin.reduce(O, axis=0)
            for i in range(M):
                _, Rank = msort(O[:, i])
                CrowdDis[Front[Rank[0]]] = np.inf
                CrowdDis[Front[Rank[-1]]] = np.inf
                if len(Front) > 2:
                    mid = Front[Rank[1:-1]]
                    CrowdDis[mid] = CrowdDis[mid] + (O[Rank[2:], i] - O[Rank[:-2], i]) / (Fmax[i] - Fmin[i])
    return CrowdDis


def TournamentSelection(K, N, *fitness, rng=None):
    """K-tournament selection of N indices (0-based); lexicographic comparison of the fitness
    vectors, smaller is better; among equal candidates the first drawn wins."""
    cols = [np.asarray(f, dtype=float).reshape(-1) for f in fitness]
    Fit = np.column_stack(cols)
    _, _, Loc = unique_rows(Fit)                  # rank of each unique row == lexicographic order
    Parents = rng.integers(0, len(cols[0]), size=(int(K), int(N)))
    best = np.argmin(Loc[Parents], axis=0)
    return Parents[best, np.arange(int(N))]


def UniformPoint(N, M):
    """Uniformly distributed reference points on the unit simplex (normal-boundary intersection).

    Returns the (n, M) weight matrix and its number of rows n.
    """
    return _nbi(N, int(M))


def _simplex_lattice(H, M):
    C = np.array(list(combinations(range(1, H + M), M - 1)), dtype=float).reshape(-1, M - 1)
    W = C - np.arange(M - 1)[None, :] - 1
    n = W.shape[0]
    return (np.hstack([W, np.full((n, 1), float(H))]) - np.hstack([np.zeros((n, 1)), W])) / H


def _nbi(N, M):
    H1 = 1
    while math.comb(H1 + M, M - 1) <= N:
        H1 += 1
    W = _simplex_lattice(H1, M)
    if H1 < M:
        H2 = 0
        while math.comb(H1 + M - 1, M - 1) + math.comb(H2 + M, M - 1) <= N:
            H2 += 1
        if H2 > 0:
            W2 = _simplex_lattice(H2, M)
            W = np.vstack([W, W2 / 2 + 1 / (2 * M)])
    W = np.fmax(W, 1e-6)                          # MATLAB max ignores NaN
    return W, W.shape[0]


def _type_index(Problem):
    enc = np.asarray(Problem.encoding, dtype=int).ravel()
    return [np.flatnonzero(enc == i) for i in range(1, 6)]


def _bounds(Problem, D):
    lo = np.asarray(Problem.lower, dtype=float) * np.ones(D)
    up = np.asarray(Problem.upper, dtype=float) * np.ones(D)
    return lo, up


def _poly_mutation(Off, Lower, Upper, proM_over_D, disM, rng):
    """Polynomial mutation exactly as in PlatEMO's GAreal/OperatorDE (after clipping)."""
    n, D = Off.shape
    Site = rng.random((n, D)) < proM_over_D
    mu = rng.random((n, D))
    Off = np.minimum(np.maximum(Off, Lower), Upper)
    with np.errstate(divide="ignore", invalid="ignore"):
        t = Site & (mu <= 0.5)
        L, U, m, o = Lower[t], Upper[t], mu[t], Off[t]
        Off[t] = o + (U - L) * ((2.0 * m + (1 - 2.0 * m) * (1 - (o - L) / (U - L)) ** (disM + 1)) ** (1 / (disM + 1)) - 1)
        t = Site & (mu > 0.5)
        L, U, m, o = Lower[t], Upper[t], mu[t], Off[t]
        Off[t] = o + (U - L) * (1 - (2.0 * (1 - m) + 2.0 * (m - 0.5) * (1 - (U - o) / (U - L)) ** (disM + 1)) ** (1 / (disM + 1)))
    return Off


def _sbx_beta(N, D, proC, disC, rng):
    beta = np.zeros((N, D))
    mu = rng.random((N, D))
    lo = mu <= 0.5
    beta[lo] = (2 * mu[lo]) ** (1 / (disC + 1))
    beta[~lo] = (2 - 2 * mu[~lo]) ** (-1 / (disC + 1))
    beta = beta * (-1.0) ** rng.integers(0, 2, size=(N, D))
    beta[rng.random((N, D)) < 0.5] = 1
    beta[np.repeat(rng.random((N, 1)) > proC, D, axis=1)] = 1
    return beta


def _ga_real(P1, P2, lower, upper, proC, disC, proM, disM, rng, half):
    N, D = P1.shape
    beta = _sbx_beta(N, D, proC, disC, rng)
    if half:
        Off = (P1 + P2) / 2 + beta * (P1 - P2) / 2
        n = N
    else:
        Off = np.vstack([(P1 + P2) / 2 + beta * (P1 - P2) / 2, (P1 + P2) / 2 - beta * (P1 - P2) / 2])
        n = 2 * N
    Lower = np.tile(lower, (n, 1))
    Upper = np.tile(upper, (n, 1))
    return _poly_mutation(Off, Lower, Upper, proM / D, disM, rng)


def _uniform_cross(P1, P2, proC, rng):
    N, D = P1.shape
    k = rng.random((N, D)) < 0.5
    k[np.repeat(rng.random((N, 1)) > proC, D, axis=1)] = False
    return k


def _ga_label(P1, P2, lower, upper, proC, proM, rng):
    N, D = P1.shape
    k = _uniform_cross(P1, P2, proC, rng)
    O1, O2 = P1.copy(), P2.copy()
    O1[k], O2[k] = P2[k], P1[k]
    Off = np.vstack([O1, O2])
    Site = rng.random((2 * N, D)) < proM / D
    Rand = np.round(unifrnd(np.tile(lower, (2 * N, 1)), np.tile(upper, (2 * N, 1)), rng=rng))
    Off[Site] = Rand[Site]
    return Off


def _ga_label_half(P1, P2, proC, proM, rng):
    N, D = P1.shape
    k = _uniform_cross(P1, P2, proC, rng)
    Off = P1.copy()
    Off[k] = P2[k]
    Site = rng.random((N, D)) < proM / D
    Rand = rng.integers(1, D + 1, size=(N, D)).astype(float)
    Off[Site] = Rand[Site]
    for i in range(N):                              # relabel by order of first occurrence
        Lab = np.zeros(D)
        while not np.all(Lab):
            x = np.flatnonzero(Lab == 0)[0]
            Lab[Off[i] == Off[i, x]] = Lab.max() + 1
        Off[i] = Lab
    return Off


def _ga_binary(P1, P2, proC, proM, rng, half):
    N, D = P1.shape
    k = _uniform_cross(P1, P2, proC, rng)
    if half:
        Off = P1.copy()
        Off[k] = P2[k]
    else:
        O1, O2 = P1.copy(), P2.copy()
        O1[k], O2[k] = P2[k], P1[k]
        Off = np.vstack([O1, O2])
    Site = rng.random(Off.shape) < proM / D
    Off[Site] = 1.0 - (Off[Site] != 0)
    return Off


def _setdiff_stable(a, b):
    bs = set(b.tolist())
    return np.array([v for v in a if v not in bs], dtype=float)


def _insert_move(row, s, k):
    """PlatEMO insertion mutation with 1-based s, k."""
    D = len(row)
    if s < k:
        idx = list(range(1, s)) + [k] + list(range(s, k)) + list(range(k + 1, D + 1))
    elif s > k:
        idx = list(range(1, k)) + list(range(k + 1, s)) + [k] + list(range(s, D + 1))
    else:
        return row
    return row[np.asarray(idx) - 1]


def _ga_permutation(P1, P2, proC, rng, half):
    N, D = P1.shape
    if half:
        Off = P1.copy()
        k = rng.integers(1, D + 1, size=N)
        for i in range(N):
            if rng.random() < proC:
                Off[i, k[i]:] = _setdiff_stable(P2[i], P1[i, :k[i]])
        n = N
    else:
        Off = np.vstack([P1, P2]).copy()
        k = rng.integers(1, D + 1, size=2 * N)
        for i in range(N):
            if rng.random() < proC:
                Off[i, k[i]:] = _setdiff_stable(P2[i], P1[i, :k[i]])
                Off[i + N, k[i]:] = _setdiff_stable(P1[i], P2[i, :k[i]])
        n = 2 * N
    k = rng.integers(1, D + 1, size=n)
    s = rng.integers(1, D + 1, size=n)
    for i in range(n):
        Off[i] = _insert_move(Off[i], int(s[i]), int(k[i]))
    return Off


def _ga(Problem, Parent, Parameter, rng, half):
    proC, disC, proM, disM = (1, 20, 1, 20) if Parameter is None else tuple(Parameter)
    rng = _rng_of(Problem, rng)
    evaluated = isinstance(Parent, Pop)
    PD = Parent.decs if evaluated else np.asarray(Parent, dtype=float)
    h = PD.shape[0] // 2
    P1, P2 = PD[:h], PD[h:2 * h]
    D = P1.shape[1]
    Off = np.zeros((h if half else 2 * h, D))
    T = _type_index(Problem)
    lower, upper = _bounds(Problem, D)
    r = np.concatenate([T[0], T[1]])
    if r.size:
        pm = proM if half else proM * len(r) / D
        Off[:, r] = _ga_real(P1[:, r], P2[:, r], lower[r], upper[r], proC, disC, pm, disM, rng, half)
    if T[2].size:
        if half:
            Off[:, T[2]] = _ga_label_half(P1[:, T[2]], P2[:, T[2]], proC, proM, rng)
        else:
            Off[:, T[2]] = _ga_label(P1[:, T[2]], P2[:, T[2]], lower[T[2]], upper[T[2]], proC,
                                     proM * len(T[2]) / D, rng)
    if T[3].size:
        pm = proM if half else proM * len(T[3]) / D
        Off[:, T[3]] = _ga_binary(P1[:, T[3]], P2[:, T[3]], proC, pm, rng, half)
    if T[4].size:
        Off[:, T[4]] = _ga_permutation(P1[:, T[4]], P2[:, T[4]], proC, rng, half)
    return Problem.evaluate(Off) if evaluated else Off


def OperatorGA(Problem, Parent, Parameter=None, rng=None):
    """SBX + polynomial mutation (real/integer), uniform crossover + reset (label) / bit-flip
    (binary), order crossover + insertion (permutation). Two offspring per parent pair: first
    half of Parent pairs with the second half. Parameter = (proC, disC, proM, disM) = (1,20,1,20)."""
    return _ga(Problem, Parent, Parameter, rng, half=False)


def OperatorGAhalf(Problem, Parent, Parameter=None, rng=None):
    """As OperatorGA but one offspring per pair; as in PlatEMO, proM is not rescaled by the share of each
    variable type, and label offspring are relabeled by first occurrence."""
    return _ga(Problem, Parent, Parameter, rng, half=True)
