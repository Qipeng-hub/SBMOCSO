"""SBMOCSO: sparse binary multi-objective competitive swarm optimizer for gene selection."""
