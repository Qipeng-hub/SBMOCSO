"""Bi-objective quality indicators (minimization)."""
from __future__ import annotations

import numpy as np


def nondominated(P):
    """Non-dominated rows of a two-column objective matrix, sorted by the first objective."""
    P = np.asarray(P, dtype=float)
    if len(P) == 0:
        return P
    order = np.lexsort((P[:, 1], P[:, 0]))
    Q = P[order]
    keep, best = [], np.inf
    for i, p in enumerate(Q):
        if p[1] < best:
            keep.append(i)
            best = p[1]
    return np.unique(Q[keep], axis=0)


def hv2d(P, ref=(1.0, 1.0)):
    """Exact hypervolume of the points that dominate the reference point."""
    P = np.asarray(P, dtype=float)
    if len(P) == 0:
        return 0.0
    P = P[np.all(P < np.asarray(ref), axis=1)]
    if len(P) == 0:
        return 0.0
    F = nondominated(P)
    F = F[np.argsort(F[:, 0])]
    hv, prev_y = 0.0, ref[1]
    for x, yv in F:
        hv += (ref[0] - x) * (prev_y - yv)
        prev_y = yv
    return float(hv)
