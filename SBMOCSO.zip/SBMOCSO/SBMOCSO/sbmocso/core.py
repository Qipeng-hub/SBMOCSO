"""Population container and budgeted evaluation for multi-objective algorithms.

    result = algorithm.run(task, **params)

* task.evaluate(dec) repairs the decision vectors, computes objectives and constraints, counts the
  evaluations and returns a Pop; task.evaluate(dec, add) also stores extra rows, e.g. velocities.
* task.initialization(N) creates and evaluates a random population.
* task.not_terminated(pop) records pop as the current result and returns FE < maxFE. The budget is
  checked once per generation, so the last generation may exceed it.
* task.rng (numpy Generator) is the only source of random numbers.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


class Pop:
    """Set of solutions stored as arrays.

    pop.decs, pop.objs, pop.cons and pop.adds are (N, *) arrays; pop[idx] selects rows with any numpy
    index, and Pop.cat(a, b, ...) concatenates populations.
    """

    __slots__ = ("decs", "objs", "cons", "adds")

    def __init__(self, decs, objs, cons, adds=None):
        self.decs = np.asarray(decs, dtype=float).reshape(len(decs), -1) if len(decs) else np.zeros((0, 0))
        self.objs = np.asarray(objs, dtype=float).reshape(len(decs), -1) if len(decs) else np.zeros((0, 0))
        self.cons = np.asarray(cons, dtype=float).reshape(len(decs), -1) if len(decs) else np.zeros((0, 0))
        self.adds = None if adds is None else np.asarray(adds, dtype=float).reshape(len(decs), -1)

    def __len__(self):
        return self.decs.shape[0]

    def __getitem__(self, idx):
        idx = _as_index(idx)
        return Pop(self.decs[idx], self.objs[idx], self.cons[idx],
                   None if self.adds is None else self.adds[idx])

    @staticmethod
    def cat(*pops: "Pop") -> "Pop":
        pops = [p for p in pops if p is not None and len(p) > 0]
        if not pops:
            return Pop.empty()
        adds = None
        if all(p.adds is not None for p in pops):
            adds = np.vstack([p.adds for p in pops])
        return Pop(np.vstack([p.decs for p in pops]), np.vstack([p.objs for p in pops]),
                   np.vstack([p.cons for p in pops]), adds)

    @staticmethod
    def empty() -> "Pop":
        p = Pop.__new__(Pop)
        p.decs = p.objs = p.cons = np.zeros((0, 0))
        p.adds = None
        return p

    @property
    def cv(self) -> np.ndarray:
        """Overall constraint violation, sum(max(0, con)) per solution."""
        return np.sum(np.maximum(0.0, self.cons), axis=1)

    @property
    def feasible(self) -> np.ndarray:
        return np.all(self.cons <= 0, axis=1)

    def with_adds(self, adds) -> "Pop":
        return Pop(self.decs, self.objs, self.cons, adds)


def _as_index(idx):
    if isinstance(idx, (int, np.integer)):
        return np.array([idx])
    if isinstance(idx, list):
        return np.asarray(idx, dtype=int) if not (idx and isinstance(idx[0], (bool, np.bool_))) else np.asarray(idx)
    return idx


class MOTask:
    """Budgeted evaluation of a multi-objective problem.

    The problem provides M, D, lower, upper, encoding (1 real, 2 integer, 3 label, 4 binary,
    5 permutation), cal_obj(dec) -> (N, M) and cal_con(dec) -> (N, C), where con <= 0 is feasible.
    """

    def __init__(self, problem, N: int, max_fes: int, seed: int, n_save: int = 1):
        self.problem = problem
        self.M, self.D = int(problem.M), int(problem.D)
        self.lower = np.asarray(problem.lower, dtype=float) * np.ones(self.D)
        self.upper = np.asarray(problem.upper, dtype=float) * np.ones(self.D)
        self.encoding = np.asarray(getattr(problem, "encoding", np.ones(self.D)), dtype=int) * np.ones(self.D, dtype=int)
        self.N = int(N)
        self.max_fes = int(max_fes)
        self.seed = int(seed)
        self.rng = np.random.default_rng(seed)
        self.FE = 0
        self.n_save = max(1, int(n_save))
        self.history: list[tuple[int, Pop]] = []
        self.history_fe: list[int] = []      # evaluations used when each checkpoint was taken
        self.final: Pop | None = None

    @property
    def maxFE(self) -> int:
        return self.max_fes

    def cal_dec(self, dec):
        if hasattr(self.problem, "cal_dec"):
            return self.problem.cal_dec(dec)
        dec = np.minimum(np.maximum(dec, self.lower), self.upper)
        idx = np.isin(self.encoding, (2, 3, 4))
        if idx.any():
            dec[:, idx] = np.round(dec[:, idx])
        return dec

    def evaluate(self, dec, add=None) -> Pop:
        dec = np.atleast_2d(np.array(dec, dtype=float, copy=True))
        dec = self.cal_dec(dec)
        obj = np.asarray(self.problem.cal_obj(dec), dtype=float).reshape(dec.shape[0], -1)
        con = np.asarray(self.problem.cal_con(dec), dtype=float).reshape(dec.shape[0], -1)
        self.FE += dec.shape[0]
        return Pop(dec, obj, con, add)

    def initialization(self, N: int | None = None) -> Pop:
        N = self.N if N is None else int(N)
        dec = np.zeros((N, self.D))
        enc = self.encoding
        r = (enc == 1) | (enc == 2) | (enc == 3)
        if r.any():
            u = self.rng.uniform(self.lower[r], self.upper[r], size=(N, int(r.sum())))
            dec[:, r] = u
            ir = np.isin(enc, (2, 3))
            if ir.any():
                dec[:, ir] = np.round(dec[:, ir])
        b = enc == 4
        if b.any():
            dec[:, b] = self.rng.integers(0, 2, size=(N, int(b.sum())))
        p = enc == 5
        if p.any():
            dec[:, p] = np.argsort(self.rng.random((N, int(p.sum()))), axis=1) + 1
        return self.evaluate(dec)

    def not_terminated(self, pop: Pop) -> bool:
        self.final = pop
        if self.n_save > 1:
            k = max(1, min(self.n_save, int(np.ceil(self.n_save * self.FE / self.max_fes))))
            if not self.history or self.history[-1][0] < k:
                self.history.append((k, pop))
                self.history_fe.append(self.FE)
        return self.FE < self.max_fes

    def result(self, **extra) -> "MOResult":
        p = self.final if self.final is not None else Pop.empty()
        return MOResult(decs=p.decs, objs=p.objs, cons=p.cons, fes=self.FE, extra=extra)


@dataclass
class MOResult:
    decs: np.ndarray
    objs: np.ndarray
    cons: np.ndarray
    fes: int
    extra: dict = field(default_factory=dict)
