"""Bi-objective gene selection problem.

Both objectives are minimized:
    f1 = fraction of selected genes,
    f2 = balanced error of a 3-NN classifier on the training part, where the neighbors of a sample
         are restricted to samples of other donors (leave-one-out when every donor gives one sample).
A decision vector selects gene j when dec[j] > 0.5, so the same problem serves binary-coded
algorithms (dec in {0, 1}) and real-coded algorithms (dec in [0, 1]).
"""
from __future__ import annotations

import os
from pathlib import Path

import numpy as np

DATA_DIR = Path(os.environ.get("SBMOCSO_DATA", Path(__file__).resolve().parents[1] / "data" / "processed"))
DATASETS = ["AMD-RPE-GSE29801", "AMD-RET-GSE29801", "UM-GSE22138", "UM-GSE44295", "TED-GSE58331", "DR-GSE160306"]
K_NN = 3
SPLIT_SEED = 10_000


def grouped_stratified_split(y, groups, seed, test_frac=0.3):
    """Assign whole donors to the test part so that about test_frac of the donors of each class are held out."""
    rng = np.random.default_rng(seed)
    y = np.asarray(y)
    groups = np.asarray(groups)
    ug = np.unique(groups)
    glab = np.array([int(round(y[groups == g].mean())) for g in ug])
    test_groups = []
    for c in (0, 1):
        gc = ug[glab == c]
        gc = gc[rng.permutation(len(gc))]
        k = int(round(test_frac * len(gc)))
        test_groups.extend(gc[:k].tolist())
    te = np.isin(groups, test_groups)
    return np.where(~te)[0], np.where(te)[0]


def balanced_error(y_true, y_pred):
    errs = [np.mean(y_pred[y_true == c] != c) for c in np.unique(y_true)]
    return float(np.mean(errs))


def _knn_vote(idx, ytr, k=K_NN):
    """Majority vote of the k nearest neighbors for labels 0/1 (k is odd, so there are no ties)."""
    return (ytr[idx[:, :k]].sum(axis=1) * 2 > k).astype(int)


class GeneSelection:
    """Gene selection on one dataset and one train/test split.

    dataset : name of a file <dataset>.npz in DATA_DIR with arrays X, y, groups, feat and sym
    run     : split index; the split is drawn with seed SPLIT_SEED + run
    coding  : "binary" (encoding 4) or "real" (encoding 1)
    """

    def __init__(self, dataset=DATASETS[0], run=0, coding="binary", data_dir=None):
        d = np.load(Path(data_dir or DATA_DIR) / f"{dataset}.npz", allow_pickle=False)
        X, y, g = d["X"].astype(float), d["y"].astype(int), d["groups"]
        self.feat, self.sym = d["feat"], d["sym"]
        tr, te = grouped_stratified_split(y, g, seed=SPLIT_SEED + int(run))
        mu, sd = X[tr].mean(axis=0), X[tr].std(axis=0)
        sd[sd == 0] = 1.0
        Z = (X - mu) / sd
        self.Xtr, self.ytr, self.Xte, self.yte = Z[tr], y[tr], Z[te], y[te]
        self.tr_idx, self.te_idx = tr, te
        gtr = np.asarray(g)[tr]
        self.same_donor = gtr[:, None] == gtr[None, :]
        self.dataset, self.run, self.coding = dataset, int(run), coding
        self.name = f"GeneSelection[{dataset},r{run},{coding}]"
        self.M = 2
        self.D = X.shape[1]
        self.lower = np.zeros(self.D)
        self.upper = np.ones(self.D)
        self.encoding = np.full(self.D, 4 if coding == "binary" else 1, dtype=int)

    def cal_dec(self, dec):
        dec = np.minimum(np.maximum(np.asarray(dec, dtype=float), self.lower), self.upper)
        idx = np.isin(self.encoding, (2, 3, 4))
        if idx.any():
            dec[:, idx] = np.round(dec[:, idx])
        return dec

    def masks(self, dec):
        return np.asarray(dec) > 0.5

    def cal_obj(self, dec):
        mask = self.masks(dec)
        out = np.empty((mask.shape[0], 2))
        out[:, 0] = mask.mean(axis=1)
        for i, m in enumerate(mask):
            out[i, 1] = self._train_error(m)
        return out

    def cal_con(self, dec):
        return np.zeros((np.asarray(dec).shape[0], 0))

    def _train_error(self, m):
        if not m.any():
            return 1.0
        A = self.Xtr[:, m]
        sq = np.einsum("ij,ij->i", A, A)
        D2 = sq[:, None] + sq[None, :] - 2.0 * (A @ A.T)
        D2[self.same_donor] = np.inf
        idx = np.argsort(D2, axis=1, kind="stable")
        return balanced_error(self.ytr, _knn_vote(idx, self.ytr))

    def test_error(self, dec):
        """Balanced 3-NN error on the test part, with the training part as the reference set."""
        mask = self.masks(np.atleast_2d(dec))
        out = np.empty(mask.shape[0])
        for i, m in enumerate(mask):
            if not m.any():
                out[i] = 1.0
                continue
            A, B = self.Xtr[:, m], self.Xte[:, m]
            D2 = (B * B).sum(1)[:, None] + (A * A).sum(1)[None, :] - 2.0 * (B @ A.T)
            idx = np.argsort(D2, axis=1, kind="stable")
            out[i] = balanced_error(self.yte, _knn_vote(idx, self.ytr))
        return out
